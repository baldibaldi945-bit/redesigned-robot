"""PortYou Brain v2 (reference implementation; Brain.kt mirrors it).

Works out what a custom event / note type DOES and writes Psych Engine 1.0 Lua for it.
Evidence, strongest first:
  1. the original source (Lua or Haxe): real API calls + their literal arguments
  2. how the chart USES it: value shapes of every event row, side / sustain / count of every note
  3. the name: split into words, English + Spanish + Portuguese, also glued names (slowzoom, multsv)
Every generated callback is wrapped in pcall, so a wrong guess can never crash a song.
Nothing here needs the internet or an AI model.
"""
import re
from collections import Counter

# ----------------------------------------------------------------------------- vocabulary (name words)
VOCAB = {
    'flash': ['flash', 'flashes', 'flashing', 'destello', 'relampago', 'flashbang'],
    'shake': ['shake', 'shaking', 'earthquake', 'rumble', 'vibrate', 'tremor', 'temblor', 'sacudir', 'kaboom'],
    'zoom': ['zoom', 'bump', 'boom', 'bounce', 'pulse', 'camzoom', 'acercar'],
    'fade': ['fade', 'fadeout', 'blackout', 'darken', 'darkness', 'oscuro', 'apagar', 'dim', 'dark'],
    'hud': ['hud', 'ui', 'gui', 'interface', 'hidehud', 'showhud'],
    'anim': ['anim', 'animation', 'animacion', 'playanim', 'play'],
    'hey': ['hey', 'cheer'],
    'follow': ['focus', 'follow', 'forced', 'camerapos', 'campos', 'camfollow'],
    'bop': ['modulo', 'bopping', 'bumpmodulo', 'bopspeed'],
    'call': ['hscript', 'call'],
    'speed': ['speed', 'scrollspeed', 'velocidad'],
    'char': ['changechar', 'switchchar', 'swapchar', 'transformation', 'personaje', 'character'],
    'text': ['text', 'lyrics', 'lyric', 'subtitle', 'subtitles', 'caption', 'dialogue', 'say', 'letra'],
    'angle': ['rotate', 'angle', 'spin', 'speen', 'tilt', 'giro', 'rotar'],
    'bpm': ['bpm', 'tempo'],
    'shader': ['chroma', 'shader', 'glitch', 'vhs', 'blur', 'drunk', 'bloom', 'mosaic', 'pixelate', 'saturation',
               'contrast', 'vignette', 'grayscale', 'filter', 'effect'],
    'sound': ['sound', 'sfx', 'audio', 'sonido'],
    'jump': ['jump', 'hop', 'fly', 'float', 'levitate', 'salto', 'volar'],
    'move': ['move', 'slide', 'shift', 'teleport', 'dash', 'mover', 'walk'],
    'dodge': ['dodge', 'avoid', 'qte', 'space', 'spacebar', 'parry', 'esquivar', 'pistola', 'dispar', 'shoot'],
    'lives': ['lives', 'life', 'revive', 'vidas', 'extralife'],
    'icon': ['icon', 'icono'],
    'visible': ['show', 'hide', 'appear', 'disappear', 'spawn', 'remove', 'toggle', 'visibility', 'visible', 'aparece'],
    'video': ['video', 'cutscene', 'chromavideo'],
    'bars': ['bars', 'cinematic', 'cinema', 'cine', 'letterbox'],
    'stagezoom': ['stagezoom', 'defaultzoom', 'zoomadjust'],
    'strums': ['strum', 'strums', 'arrows', 'arrow', 'middlescroll', 'notes'],
}
# glued names: look inside the lower-cased name for these stems
STEMS = sorted({w for ws in VOCAB.values() for w in ws if len(w) >= 4}, key=len, reverse=True)


def words(name):
    s = re.sub(r'([a-z0-9])([A-Z])', r'\1 \2', name)
    out = [w for w in re.split(r'[^A-Za-z0-9]+', s.lower()) if w]
    glued = set(out)
    low = re.sub(r'[^a-z0-9]', '', name.lower())
    for st in STEMS:
        if st in low:
            glued.add(st)
    return glued


def name_intents(name):
    ws = words(name)
    return {k for k, vs in VOCAB.items() if any(v in ws for v in vs)}


# ----------------------------------------------------------------------------- source evidence (Lua / Haxe)
SRC_RULES = [  # (intent, regex over the source)
    ('flash', r'cameraFlash|camera\.flash|\.flash\(|FlxG\.camera\.flash|screenFlash'),
    ('shake', r'cameraShake|\.shake\(|camera\.shake'),
    ('zoom', r'doTweenZoom|defaultCamZoom|camGame\.zoom|cameraZoom|camZooming'),
    ('fade', r'cameraFade|\.fade\(|doTweenAlpha\([^)]*(black|fade)'),
    ('hud', r'camHUD\.alpha|camHUD.visible|hideHud|healthBar\.visible|setProperty\([\'"]camHUD'),
    ('anim', r'playAnim|characterPlayAnim|animation\.play|playAnimation|objectPlayAnimation'),
    ('follow', r'cameraSetTarget|camFollow|isCameraOnForcedPos|moveCamera'),
    ('speed', r'songSpeed|scrollSpeed|noteTween'),
    ('char', r'changeCharacter|addCharacterToList|Change Character'),
    ('text', r'makeLuaText|setTextString|FlxText'),
    ('angle', r'doTweenAngle|\.angle\b'),
    ('bpm', r'Conductor\.bpm|changeBPM|setBPM'),
    ('shader', r'initLuaShader|createRuntimeShader|setSpriteShader|ShaderFilter'),
    ('sound', r'playSound|FlxG\.sound|FunkinSound'),
    ('dodge', r'keyJustPressed|keyboardJustPressed|FlxG\.keys\.justPressed|justPressed'),
    ('lives', r'function onGameOver|onGameOver\b'),
    ('icon', r'iconP[12]|changeIcon|healthIcon'),
    ('visible', r'\.visible|removeLuaSprite|addLuaSprite'),
    ('video', r'startVideo|FlxVideo|VideoSprite'),
    ('strums', r'strumLineNotes|opponentStrums|playerStrums|noteTween[XYA]'),
    ('move', r'doTweenX|doTweenY|setProperty\([\'"](boyfriend|dad|gf)\.[xy]'),
    ('circle', r'math\.(sin|cos)|Math\.(sin|cos)'),
]


def source_intents(src):
    if not src:
        return set()
    return {k for k, rx in SRC_RULES if re.search(rx, src)}


def src_numbers(src, rx, default):
    if not src:
        return default
    m = re.search(rx, src, re.I)
    try:
        return float(m.group(1)) if m else default
    except Exception:
        return default


def src_keys(src):
    """keys the original listens for: keyJustPressed('space') / FlxG.keys.justPressed.SPACE"""
    ks = set()
    for m in re.finditer(r'keyJustPressed\(\s*[\'"]([A-Za-z0-9_]+)[\'"]', src or ''):
        ks.add(m.group(1).lower())
    for m in re.finditer(r'keyboardJustPressed\(\s*[\'"]([A-Za-z0-9_]+)[\'"]', src or ''):
        ks.add(m.group(1).upper())
    for m in re.finditer(r'justPressed\.([A-Z0-9_]+)', src or ''):
        ks.add(m.group(1).upper())
    return ks


# ----------------------------------------------------------------------------- usage evidence (the chart)
HEX = re.compile(r'^#?[0-9a-fA-F]{6}$')
NUM = re.compile(r'^-?\d+(\.\d+)?$')
BOOL = {'true', 'false', 'on', 'off', 'yes', 'no', '1', '0'}
CHARS = {'bf', 'boyfriend', 'dad', 'opponent', 'gf', 'girlfriend', 'player', 'dad2', 'bf2'}
EASE = re.compile(r'^(linear|quad|cube|quart|quint|sine|expo|circ|back|elastic|bounce|smooth|smoother)(in|out|inout)?$', re.I)


def shape(v):
    """classify one value string"""
    v = (v or '').strip()
    if v == '':
        return 'empty'
    if v.startswith('{') and v.endswith('}'):
        return 'json'
    if ',' in v:
        parts = [p.strip() for p in v.split(',')]
        sh = [shape(p) for p in parts]
        if all(s in ('num', 'bool', 'ease') for s in sh):
            return 'csv:' + '/'.join(sh)
        return 'csv'
    if NUM.match(v):
        return 'num'
    if v.lower() in BOOL:
        return 'bool'
    if v.lower() in CHARS:
        return 'char'
    if HEX.match(v):
        return 'hex'
    if EASE.match(v):
        return 'ease'
    return 'str'


def usage_intents(samples):
    """samples: list of (value1, value2). Returns {intent: reason}."""
    out = {}
    if not samples:
        return out
    s1 = Counter(shape(a) for a, _ in samples)
    s2 = Counter(shape(b) for _, b in samples)
    top1 = s1.most_common(1)[0][0]
    top2 = s2.most_common(1)[0][0]
    if top1 == 'hex':
        out['flash'] = 'value1 is a colour'
    if top1 == 'char' or top2 == 'char':
        out['follow'] = 'a character is named'
    if top1 == 'bool' and top2 in ('char', 'empty'):
        out['follow'] = 'bool + character = forced camera target'
    if top1.startswith('csv:bool') or top1.startswith('csv:num'):
        out['shader'] = 'comma list of bool/numbers (effect settings)'
    if top1 == 'json':
        out['json'] = 'json payload'
    if top1 == 'str':
        sent = sum(1 for a, _ in samples if ' ' in (a or '').strip() or len((a or '').strip()) > 14)
        if sent * 2 >= len(samples):
            out['text'] = 'sentences'
        else:
            out['name_arg'] = 'single words (an id / function name / file)'
    return out


# ----------------------------------------------------------------------------- Lua writers
def q(s):
    return "'" + s.replace('\\', '\\\\').replace("'", "\\'") + "'"


def n(d):
    return str(int(d)) if float(d).is_integer() and abs(d) < 1e9 else repr(round(d, 4))


PV = ("local function pv(s, k, d) if s == nil then return d end "
      "local v = string.match(tostring(s), k .. '=([^;]+)') if v ~= nil then return tonumber(v) or v end "
      "return tonumber(s) or d end\n"
      "local function csv(s) local t = {} for x in string.gmatch(tostring(s or ''), '[^,]+') do t[#t + 1] = (x:gsub('^%s+', ''):gsub('%s+$', '')) end return t end\n"
      "local function tcol(s) s = tostring(s or ''):gsub('#', '') if #s == 6 then return s end return 'FFFFFF' end\n")


def frag_for(kind, shaders):
    """which .frag of the mod does this effect name point at? (bloom effect -> bloom.frag)"""
    ws = {w for w in re.split(r'[^a-z0-9]+', re.sub(r'([a-z0-9])([A-Z])', r'\1 \2', kind).lower()) if w and w not in ('effect', 'event', 'toggle', 'screen', 'camera')}
    low = re.sub(r'[^a-z0-9]', '', kind.lower())
    best = None
    for sh in shaders or []:
        base = re.sub(r'[^a-z0-9]', '', sh.lower().replace('.frag', ''))
        if any(x in base for x in ('glitch', 'clip', 'copy', 'old')) and not any(x in low for x in ('glitch', 'clip', 'copy', 'old')):
            continue
        if any(w == base or (len(w) > 3 and base.startswith(w)) or (len(w) > 5 and w in base) for w in ws) or (len(base) > 4 and base in low):
            if best is None or len(base) < len(re.sub(r'[^a-z0-9]', '', best.lower().replace('.frag', ''))):
                best = sh
    return best


def synth_event(kind, src=None, samples=None, anims=None, shaders=None):
    """returns (lua, explanation, confidence 0..1)"""
    # Exact mapping recovered from the supplied MarvinousTween Haxe snippets.
    # The event's value1 selects regular/custom; value2 supplies the zoom settings.
    if re.sub(r'[^a-z0-9]', '', (kind or '').lower()) == 'marvinoustween':
        event_name = q(kind)
        lua = """-- PortYou: faithful mapping of MarvinousTween.hxc (regular/custom modes)
local function pyMarvinousTween(value1, value2)
    local mode = string.lower(tostring(value1 or ''))
    local target, duration, ease
    if mode == 'regular' then
        target, duration, ease = tonumber(value2), 0.3, 'cubeOut'
    elseif mode == 'custom' then
        local parts = {}
        for part in string.gmatch(tostring(value2 or ''), '[^,]+') do
            parts[#parts + 1] = string.match(part, '^%s*(.-)%s*$')
        end
        if #parts < 3 then return end
        target = tonumber(parts[1]); if target == nil or target ~= target then target = 1.0 end
        duration = tonumber(parts[2]); if duration == nil or duration ~= duration then duration = 0.5 end
        local easeMap = {
            linear='linear',
            sinein='sineIn', sineout='sineOut', sineinout='sineInOut',
            quadin='quadIn', quadout='quadOut', quadinout='quadInOut',
            cubicin='cubeIn', cubicout='cubeOut', cubicinout='cubeInOut',
            quartin='quartIn', quartout='quartOut', quartinout='quartInOut',
            quintin='quintIn', quintout='quintOut', quintinout='quintInOut',
            expoin='expoIn', expoout='expoOut', expoinout='expoInOut',
            circin='circIn', circout='circOut', circinout='circInOut',
            backin='backIn', backout='backOut', backinout='backInOut',
            bouncein='bounceIn', bounceout='bounceOut', bounceinout='bounceInOut',
            elasticin='elasticIn', elasticout='elasticOut', elasticinout='elasticInOut'
        }
        ease = easeMap[string.lower(parts[3])] or 'linear'
    else return end
    if target == nil or target ~= target then return end
    doTweenZoom('marvinousTweenZoom', 'camGame', target, duration, ease)
end
function onEvent(name, value1, value2)
    if name == EVENT_NAME then pyMarvinousTween(value1, value2) end
end
""".replace('EVENT_NAME', event_name)
        return lua, 'regular/custom zoom tween mapped from supplied Haxe implementation', 1.0

    ev = {}                                        # intent -> reason
    for i in source_intents(src):
        ev[i] = 'source'
    for i, why in usage_intents(samples).items():
        ev.setdefault(i, 'chart: ' + why)
    for i in name_intents(kind):
        ev.setdefault(i, 'name')
    keys = src_keys(src)
    dur = src_numbers(src, r'(?:duration|time|length)\D{0,12}([0-9]*\.?[0-9]+)', 0.5)
    power = src_numbers(src, r'(?:intensity|amount|power|strength)\D{0,12}([0-9]*\.?[0-9]+)', 0.02)
    shape1 = Counter(shape(a) for a, _ in (samples or [])).most_common(1)
    shape1 = shape1[0][0] if shape1 else ''
    # priority fixes: a CSV effect payload is a screen effect, not a zoom
    if shape1.startswith('csv:') and 'zoom' in ev and ev['zoom'] != 'source':
        ev.pop('zoom', None)
    if 'circle' in ev and 'angle' not in ev:
        ev['angle'] = ev['circle']
    ev.pop('circle', None)
    if 'video' in ev:
        ev.pop('shader', None); ev.pop('text', None)
    if 'stagezoom' in ev:
        ev.pop('zoom', None); ev.pop('shader', None)
    if 'bop' in ev:
        ev.pop('zoom', None); ev.pop('follow', None)
    if 'call' in ev:
        for x in ('text', 'zoom', 'follow', 'shader'):
            ev.pop(x, None)
    frag = frag_for(kind, shaders) if 'shader' in ev else None
    if kind.lower() in ('', 'a', 'd', 'h', 'b'):
        ev = {}

    pre = []
    body = []
    f = lambda s: body.append('\tpcall(function() ' + s + ' end)\n')
    keep = set(ev)
    # ---- screen effects (Bloom / Saturation / Contrast / Vignette ...): the mod's own .frag on camGame, toggled by value1
    if 'shader' in keep and frag:
        base = frag.replace('.frag', '')
        pre.append("local function fxOn(on)\n"
                   "\tif not shadersEnabled then return end\n"
                   "\tif on then\n"
                   "\t\tif not luaSpriteExists('pyFx') then makeLuaSprite('pyFx') setSpriteShader('pyFx', %s) end\n"
                   "\t\trunHaxeCode([[ game.camGame.setFilters([new ShaderFilter(game.getLuaObject('pyFx').shader)]); ]])\n"
                   "\telse\n"
                   "\t\trunHaxeCode([[ game.camGame.setFilters([]); ]])\n"
                   "\tend\nend\n" % q(base))
        f("local a = csv(value1) fxOn(a[1] == 'true' or a[1] == '1' or a[1] == 'on')")
    elif 'shader' in keep:
        body.append("\tdebugPrint('[PortYou] \"%s\": the mod has no matching shader file, effect skipped')\n" % kind.replace("'", ''))
    if 'stagezoom' in keep:
        f("local a = csv(value2) local z = tonumber(a[1]) or tonumber(value1) if z ~= nil then "
          "setProperty('defaultCamZoom', z) doTweenZoom('pyStageZoom', 'camGame', z, tonumber(a[2]) or 1, 'sineOut') end")
    if 'bop' in keep:
        f("pyBopEvery = tonumber(value1) or 4 pyBopAmt = tonumber(value2) or 1")
    if 'call' in keep:
        f("callOnLuas(tostring(value1), {tostring(value2)})")
    if 'flash' in keep:
        col = "tcol(value1)" if shape1 == 'hex' else "'FFFFFF'"
        dd = "tonumber(value2) or %s" % n(dur) if shape1 == 'hex' else "pv(value1, 'duration', %s)" % n(dur)
        f("cameraFlash('camGame', %s, %s, true)" % (col, dd))
    if 'shake' in keep:
        f("cameraShake('camGame', pv(value1, 'intensity', %s), pv(value2, 'duration', %s))" % (n(power), n(dur)))
    if 'zoom' in keep and shape1 != 'json':
        f("local z = tonumber(value1) if z == nil then z = pv(value1, 'zoom', getProperty('defaultCamZoom')) end "
          "if z > 3 then z = z * 0.01 end "
          "doTweenZoom('pyZoom', 'camGame', z, tonumber(value2) or %s, 'quadOut')" % n(dur))
    if 'fade' in keep:
        f("cameraFade('camGame', '000000', pv(value1, 'duration', %s), false)" % n(dur))
    if 'hud' in keep:
        f("doTweenAlpha('pyHud', 'camHUD', pv(value1, 'alpha', 0), pv(value2, 'duration', %s), 'linear')" % n(dur))
    if 'anim' in keep:
        f("characterPlayAnim(tostring(pv(value2, 'target', 'boyfriend')), tostring(pv(value1, 'anim', 'idle')), true)")
    if 'hey' in keep:
        f("triggerEvent('Hey!', value1 or 'Both', value2 or '0.6')")
    if 'follow' in keep:
        f("local who = string.lower(tostring(value2 or '')) if who == '' then who = string.lower(tostring(value1 or '')) end "
          "if who == 'dad' or who == 'opponent' then triggerEvent('Camera Follow Pos', '', '') setProperty('isCameraOnForcedPos', false) callMethod('moveCamera', {true}) "
          "elseif who == 'gf' or who == 'girlfriend' then callMethod('moveCamera', {'gf'}) "
          "elseif who == 'bf' or who == 'boyfriend' or who == 'player' then callMethod('moveCamera', {false}) "
          "else triggerEvent('Camera Follow Pos', tostring(pv(value1, 'x', '')), tostring(pv(value2, 'y', ''))) end")
    if 'speed' in keep:
        f("triggerEvent('Change Scroll Speed', tostring(pv(value1, 'speed', tonumber(value1) or 1)), tostring(pv(value2, 'duration', tonumber(value2) or 1)))")
    if 'char' in keep:
        f("triggerEvent('Change Character', tostring(value1), tostring(value2))")
    if 'angle' in keep:
        f("doTweenAngle('pyAngle', 'camGame', pv(value1, 'angle', 15), tonumber(value2) or %s, 'quadOut')" % n(dur))
    if 'sound' in keep:
        f("playSound(tostring(value1), tonumber(value2) or 1)")
    if 'text' in keep:
        f("makeLuaText('pyText', tostring(value1), 900, 190, 560) setTextSize('pyText', 36) setObjectCamera('pyText', 'camHUD') "
          "addLuaText('pyText') runTimer('pyTextOff', %s)" % n(max(dur, 2.0)))
    if 'video' in keep:
        f("startVideo(tostring(value1))")
    if 'bars' in keep:
        f("local on = tostring(value1) ~= 'false' and tostring(value1) ~= '0' "
          "if not luaSpriteExists('pyBarT') then "
          "makeLuaSprite('pyBarT', nil, 0, -120) makeGraphic('pyBarT', screenWidth, 120, '000000') setObjectCamera('pyBarT', 'camHUD') addLuaSprite('pyBarT', true) "
          "makeLuaSprite('pyBarB', nil, 0, screenHeight) makeGraphic('pyBarB', screenWidth, 120, '000000') setObjectCamera('pyBarB', 'camHUD') addLuaSprite('pyBarB', true) end "
          "doTweenY('pyBarT', 'pyBarT', on and 0 or -120, 0.6, 'quadOut') doTweenY('pyBarB', 'pyBarB', on and screenHeight - 120 or screenHeight, 0.6, 'quadOut')")
    if 'bpm' in keep:
        f("setProperty('songSpeed', getProperty('songSpeed'))")   # BPM is chart data in Psych; keep as no-op marker
    if 'icon' in keep:
        f("callMethod('iconP2.changeIcon', {tostring(value1)})")
    if 'visible' in keep:
        f("local o = tostring(value1) local off = tostring(value2) == '0' or tostring(value2) == 'false' "
          "if luaSpriteExists(o) then setProperty(o .. '.visible', not off) else setProperty(o .. '.visible', not off) end")
    if 'jump' in keep:
        f("local who = tostring(pv(value2, 'target', 'boyfriend')) local y0 = getProperty(who .. '.y') "
          "pyJumpWho = who pyJumpY = y0 doTweenY('pyJumpUp', who, y0 - pv(value1, 'height', 200), %s, 'quadOut') runTimer('pyJumpBack', %s)" % (n(dur / 2), n(dur / 2)))
    if 'move' in keep and 'jump' not in keep:
        f("local who = tostring(pv(value2, 'target', 'boyfriend')) pyMoveWho = who pyMoveX = getProperty(who .. '.x') pyMoveY = getProperty(who .. '.y') "
          "doTweenX('pyMoveX', who, pyMoveX + pv(value1, 'x', 0), %s, 'sineInOut') doTweenY('pyMoveY', who, pyMoveY + pv(value1, 'y', 0), %s, 'sineInOut') "
          "if string.find(tostring(value1), 'back=1') then runTimer('pyMoveBack', %s) end" % (n(dur), n(dur), n(dur + 0.5)))
    if 'dodge' in keep:
        f("pyDodgeOpen = true pyDodgeHit = false runTimer('pyDodgeEnd', pv(value1, 'window', %s))" % n(max(dur, 0.6)))
    if 'lives' in keep:
        f("pyLives = (pyLives or 0) + pv(value1, 'lives', 1)")
    if not body:
        body.append("\tdebugPrint('[PortYou] \"%s\" : no known equivalent (ignored)')\n" % kind.replace("'", ''))
    b = ['-- generated by PortYou Brain v2 for "%s"\n' % kind, PV] + pre + ['local function on_%s(value1, value2)\n' % re.sub(r'\W', '_', kind or 'x')]
    b += body + ['end\n',
                 "function onEvent(name, value1, value2)\n\tif name == %s then on_%s(value1, value2) end\nend\n" % (q(kind), re.sub(r'\W', '_', kind or 'x'))]
    tc = []
    if 'text' in keep:
        tc.append("\tif tag == 'pyTextOff' then removeLuaText('pyText', true) end\n")
    if 'jump' in keep:
        tc.append("\tif tag == 'pyJumpBack' and pyJumpWho then doTweenY('pyJumpDown', pyJumpWho, pyJumpY, %s, 'quadIn') end\n" % n(dur / 2))
    if 'move' in keep and 'jump' not in keep:
        tc.append("\tif tag == 'pyMoveBack' and pyMoveWho then doTweenX('pyMoveX2', pyMoveWho, pyMoveX, %s, 'sineInOut') doTweenY('pyMoveY2', pyMoveWho, pyMoveY, %s, 'sineInOut') end\n" % (n(dur), n(dur)))
    if 'dodge' in keep:
        tc.append("\tif tag == 'pyDodgeEnd' then if pyDodgeOpen and not pyDodgeHit then setProperty('health', getProperty('health') - 0.4) end pyDodgeOpen = false end\n")
    if tc:
        b.append('function onTimerCompleted(tag)\n' + ''.join(tc) + 'end\n')
    if 'dodge' in keep:
        kk = [k for k in keys if k] or ['space']
        cond = ' or '.join("keyJustPressed(%s)" % q(k.lower()) for k in kk)
        b.append("function onUpdate(e) if pyDodgeOpen and (%s or mouseClicked('left')) then pyDodgeHit = true end end\n" % cond)
    if 'bop' in keep:
        b.append("function onBeatHit() if pyBopEvery and pyBopEvery > 0 and curBeat % math.max(1, math.floor(pyBopEvery)) == 0 then setProperty('camGame.zoom', getProperty('camGame.zoom') + 0.015 * (pyBopAmt or 1)) setProperty('camHUD.zoom', getProperty('camHUD.zoom') + 0.03 * (pyBopAmt or 1)) end end\n")
    if 'lives' in keep:
        b.append("function onGameOver() if (pyLives or 0) > 0 then pyLives = pyLives - 1 setProperty('health', 1) return Function_Stop end return Function_Continue end\n")
    conf = 0.9 if any(v == 'source' for v in ev.values()) else (0.7 if any(v.startswith('chart') for v in ev.values()) else (0.5 if ev else 0.0))
    why = ', '.join('%s(%s)' % (k, ev[k].split(':')[0]) for k in sorted(ev)) or 'no known behaviour'
    return ''.join(b), why, conf


# ----------------------------------------------------------------------------- note types
NOTE_WORDS = {
    'harmful': ['hurt', 'mine', 'poison', 'bomb', 'death', 'skull', 'spike', 'fire', 'warning', 'danger', 'drain', 'damage',
                'kill', 'trap', 'knife', 'bullet', 'static', 'bone', 'noscope', 'explosion', 'sword', 'hell', 'glitch'],
    'heal': ['heal', 'health', 'medkit', 'potion', 'heart', 'regen', 'life', 'drop'],
    'alt': ['alt'],
    'hey': ['hey', 'cheer'],
    'noanim': ['noanim', 'noanimation', 'ghost', 'hidden', 'invis', 'phantom'],
    'second': ['opponent2', 'opponent3', 'opponent4', 'opponent5', 'plr2', 'plr3', 'third', 'second', 'duet', 'both', 'dad2', 'bf2'],
    'gf': ['gf', 'girlfriend'],
}


def synth_note(kind, src=None, usage=None, anims=None):
    """usage = {'count':int,'player':int,'opp':int,'sustain':int}; anims = animation names of the song's characters"""
    low = re.sub(r'[^a-z0-9]', '', kind.lower())
    ws = words(kind)
    hit = lambda k: any(w in low for w in NOTE_WORDS[k])
    harmful, heal, alt, hey, noanim, second, gf = (hit(k) for k in ('harmful', 'heal', 'alt', 'hey', 'noanim', 'second', 'gf'))
    ev = source_intents(src)
    keys = src_keys(src)
    dmg = src_numbers(src, r'(?:damage|health|drain)\D{0,14}([0-9]*\.?[0-9]+)', 0.4 if harmful else 0.2)
    if dmg > 1:
        dmg /= 100.0
    # the chart tells the side: a kind used only by the opponent is a sing-style note, never a damage note
    if usage and usage.get('count'):
        if usage.get('player', 0) == 0 and usage.get('opp', 0) > 0 and harmful and not ({'knife', 'bullet'} & ws):
            harmful = False
    # does a character animation carry this kind's name?  e.g. kind "ugh" + anim "singUP-ugh"
    suffix = None
    for a in (anims or []):
        la = a.lower()
        if '-' in la and re.sub(r'[^a-z0-9]', '', la.split('-', 1)[1]) == low:
            suffix = '-' + la.split('-', 1)[1]
            break
    k = q(kind)
    reasons = []
    b = ['-- generated by PortYou Brain v2 for note kind "%s"\n' % kind]
    spawn, good, opp, miss = [], [], [], []
    if harmful:
        spawn.append("setPropertyFromGroup('notes', id, 'ignoreNote', getPropertyFromGroup('notes', id, 'mustPress'))")
        good.append("setProperty('health', getProperty('health') - %s)" % n(dmg))
        reasons.append('damaging')
    if heal:
        good.append("setProperty('health', getProperty('health') + %s)" % n(dmg))
        reasons.append('healing')
    if alt:
        spawn.append("setPropertyFromGroup('notes', id, 'animSuffix', '-alt')")
        reasons.append('alt anim')
    if suffix:
        spawn.append("setPropertyFromGroup('notes', id, 'animSuffix', %s)" % q(suffix))
        reasons.append('anim suffix ' + suffix)
    if noanim:
        spawn.append("setPropertyFromGroup('notes', id, 'noAnimation', true)")
        reasons.append('no anim')
    if hey:
        good.append("characterPlayAnim('boyfriend', 'hey', true) setProperty('boyfriend.specialAnim', true)")
        reasons.append('hey')
    if second or gf:
        who = 'gf' if (gf or 'third' in low or low.endswith('3') or low.endswith('4') or low.endswith('5')) else 'gf'
        if 'both' not in low:
            spawn.append("setPropertyFromGroup('notes', id, 'noAnimation', true)")
        opp.append("playAnim('gf', ({'singLEFT', 'singDOWN', 'singUP', 'singRIGHT'})[noteData % 4 + 1], true) setProperty('gf.holdTimer', 0)")
        good.append("playAnim('gf', ({'singLEFT', 'singDOWN', 'singUP', 'singRIGHT'})[noteData % 4 + 1], true) setProperty('gf.holdTimer', 0)")
        reasons.append('extra character sings')
    if 'dodge' in ev or keys:
        good.append("if keyJustPressed('space') then playAnim('boyfriend', 'dodge', true) setProperty('boyfriend.specialAnim', true) end")
        reasons.append('dodge key')
    b.append("function onSpawnNote(id, noteData, noteType, isSustainNote)\n\tif noteType == %s then\n" % k)
    b += ['\t\tpcall(function() %s end)\n' % s for s in spawn]
    b.append('\tend\nend\n')
    b.append("function goodNoteHit(id, noteData, noteType, isSustainNote)\n\tif noteType == %s then\n" % k)
    b += ['\t\tpcall(function() %s end)\n' % s for s in good]
    b.append('\tend\nend\n')
    if opp:
        b.append("function opponentNoteHit(id, noteData, noteType, isSustainNote)\n\tif noteType == %s then\n" % k)
        b += ['\t\tpcall(function() %s end)\n' % s for s in opp]
        b.append('\tend\nend\n')
    conf = 0.9 if ev else (0.7 if usage else (0.5 if reasons else 0.0))
    return ''.join(b), (', '.join(reasons) or 'no known behaviour - plain note type'), conf
