package com.portyou.studio.convert

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Credits attached to EVERY converted mod: pack.json (English + Portuguese only, no Arabic) and pack.png. */
object Credits {
    const val EN = "This mod was ported by the AxelzeroX23 app (PortYou Studio)"
    const val PT = "Este mod foi portado pelo app do AxelzeroX23 (PortYou Studio)"
    /** Same script as the supplied text.lua, name replaced by "Port You Studio". */
    const val WATERMARK_LUA = "function onCreate()\nmakeLuaText('watermark', \"Port You Studio\", 0, 10, 550);\n    setTextSize('watermark', 20);\n    addLuaText('watermark');\nend\n"
    fun write(ctx: Context, outDir: File, modName: String, color: IntArray = intArrayOf(170, 0, 255)) {
        File(outDir, "scripts").mkdirs()
        File(outDir, "scripts/portyou_credit.lua").writeText(WATERMARK_LUA)
        File(outDir, "pack.json").writeText(JSONObject()
            .put("name", "$modName | $EN | $PT")
            .put("description", "$EN. / $PT. YouTube: axelzerox023 | Instagram: axelzerox023")
            .put("restart", false).put("runsGlobally", false)
            .put("color", JSONArray(color.toList())).put("discordRPC", ":)").put("iconFramerate", 10).toString(1))
        ctx.assets.open("converter/pack.png").use { i -> File(outDir, "pack.png").outputStream().use { i.copyTo(it) } }
    }
}
