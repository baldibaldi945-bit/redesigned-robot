package com.portyou.studio.convert

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Converts a V-Slice note style's Sparrow atlases into the single atlas layout expected by
 * Psych Engine 1.0.4. V-Slice keeps notes and receptors in separate assets; Psych's arrowSkin
 * is shared by Note and StrumNote, so their frames must be merged and renamed.
 */
internal object NoteStyleAtlas {
    data class Result(val arrowSkin: String = "", val splashSkin: String = "noteSplashes/noteSplashes")

    private data class SourceFrame(
        val name: String,
        val x: Int,
        val y: Int,
        val width: Int,
        val height: Int,
        val frameX: Int?,
        val frameY: Int?,
        val frameWidth: Int?,
        val frameHeight: Int?
    )

    private data class RenameRule(
        val outputPrefix: String,
        val offsetX: Double = 0.0,
        val offsetY: Double = 0.0,
        val frameIndices: Set<Int>? = null
    )

    private data class PackedFrame(
        val name: String,
        val bitmap: Bitmap,
        val frameX: Int?,
        val frameY: Int?,
        val frameWidth: Int?,
        val frameHeight: Int?,
        var outX: Int = 0,
        var outY: Int = 0
    )

    private val directions = linkedMapOf(
        "left" to "LEFT", "down" to "DOWN", "up" to "UP", "right" to "RIGHT"
    )

    fun convert(
        root: File,
        out: File,
        styleId: String,
        findAsset: (String, String) -> File?,
        report: (String) -> Unit
    ): Result {
        if (styleId.isBlank() || styleId.equals("funkin", true) || styleId.equals("pixel", true)) return Result()
        val safeId = styleId.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9_-]+"), "-").trim('-').ifEmpty { "custom" }
        val chain = resolveStyleChain(root, styleId, report)
        if (chain.isEmpty()) return Result().also { report("note style '$styleId' has no data/notestyles/$styleId.json; default Psych note skin retained") }

        fun resolvedAsset(key: String): JSONObject? = chain.firstNotNullOfOrNull { j ->
            val a = j.optJSONObject("assets")?.optJSONObject(key) ?: return@firstNotNullOfOrNull null
            val path = a.optString("assetPath", "").trim()
            if (path.isEmpty() || path.equals("null", true)) null else a
        }

        val note = resolvedAsset("note")
        val receptors = resolvedAsset("noteStrumline")
        val hold = resolvedAsset("holdNote")
        var arrowSkin = ""
        if (note != null && receptors != null) {
            val specs = ArrayList<Triple<JSONObject, Map<String, RenameRule>, Boolean>>()
            val noteMap = LinkedHashMap<String, RenameRule>()
            val noteData = note.optJSONObject("data") ?: JSONObject()
            for ((dir, colorPrefix) in listOf("left" to "purple0", "down" to "blue0", "up" to "green0", "right" to "red0")) {
                val anim = noteData.optJSONObject(dir) ?: continue
                val prefix = anim.optString("prefix", "")
                if (prefix.isNotBlank()) noteMap[prefix] = renameRule(colorPrefix, note, anim)
            }
            val receptorMap = LinkedHashMap<String, RenameRule>()
            val receptorData = receptors.optJSONObject("data") ?: JSONObject()
            for ((key, value) in directions) {
                val states = listOf(
                    "Static" to "arrow$key",
                    "Press" to "${value.lowercase(Locale.ROOT)} press",
                    "Confirm" to "${value.lowercase(Locale.ROOT)} confirm",
                    // Psych 1.0.4 has only one confirm animation. Keep the ordinary confirm
                    // prefix when ConfirmHold uses the same source; do not create duplicates.
                    "ConfirmHold" to "${value.lowercase(Locale.ROOT)} confirm"
                )
                for ((suffix, psychPrefix) in states) {
                    val anim = receptorData.optJSONObject(key + suffix) ?: continue
                    val sourcePrefix = anim.optString("prefix", "")
                    if (sourcePrefix.isNotBlank() && sourcePrefix !in receptorMap) receptorMap[sourcePrefix] = renameRule(psychPrefix, receptors, anim)
                }
            }
            if (noteMap.isNotEmpty() && receptorMap.isNotEmpty()) {
                specs.add(Triple(note, noteMap, false))
                specs.add(Triple(receptors, receptorMap, false))
                if (hold != null) specs.add(Triple(hold, emptyMap(), true))
                val target = File(out, "images/noteSkins/$safeId")
                if (mergeSheets(specs, target, findAsset, report, "note style '$styleId'")) {
                    arrowSkin = "noteSkins/$safeId"
                    report("note style '$styleId': note arrows + receptors merged into one Psych arrowSkin atlas")
                }
            } else {
                report("note style '$styleId': missing note/strumline animation prefixes; kept Psych's default arrow skin")
            }
        } else {
            report("note style '$styleId': note or noteStrumline asset is absent/inherited outside the mod; kept Psych's default arrow skin")
        }

        var splashSkin = "noteSplashes/noteSplashes"
        val splash = resolvedAsset("noteSplash")
        if (splash != null && splash.optJSONObject("data")?.optBoolean("enabled", true) != false) {
            val path = splash.optString("assetPath", "")
            val target = File(out, "images/noteSplashes/$safeId")
            if (path.isNotBlank() && mergeSheets(listOf(Triple(splash, emptyMap(), true)), target, findAsset, report, "note splash '$styleId'")) {
                splashSkin = "noteSplashes/$safeId"
                val xml = findAsset(path.substringAfterLast(':'), ".xml")
                if (xml != null && writeSplashConfig(splash, xml, File(target.path + ".json"), report, styleId)) {
                    report("note style '$styleId': custom Psych splash config generated for all four colors")
                } else {
                    report("note style '$styleId': splash atlas copied; automatic Psych prefix detection is retained because source color prefixes could not be mapped safely")
                }
            }
        }
        return Result(arrowSkin, splashSkin)
    }


    /**
     * Psych 1.0.4 supports a per-skin JSON config for splash animations. V-Slice does not
     * expose noteSplash animation data in its style JSON, so infer only unambiguous color
     * prefixes from the Sparrow frame names. Do not fabricate missing colors.
     */
    private fun writeSplashConfig(
        asset: JSONObject,
        xml: File,
        output: File,
        report: (String) -> Unit,
        styleId: String
    ): Boolean {
        val frames = Regex("<SubTexture\\b[^>]*?/?>").findAll(xml.readText())
            .mapNotNull { parseFrame(it.value)?.name }
            .toList()
        val colors = listOf("purple", "blue", "green", "red")
        val anims = JSONObject()
        val baseOffsets = asset.optJSONArray("offsets") ?: org.json.JSONArray("[0,0]")
        for ((noteData, color) in colors.withIndex()) {
            val candidate = frames.firstOrNull { frame ->
                val lower = frame.lowercase(Locale.ROOT)
                Regex("(^|[^a-z])${color}([^a-z]|$)").containsMatchIn(lower) ||
                    lower.startsWith(color) || lower.contains("${color}splash") || lower.contains("splash${color}")
            } ?: run {
                report("note splash '$styleId': no unambiguous '$color' frame prefix; custom config was not written")
                return false
            }
            val prefix = candidate.replace(Regex("\\d+$"), "")
            if (prefix.isBlank()) return false
            val anim = JSONObject()
                .put("name", color)
                .put("noteData", noteData)
                .put("prefix", prefix)
                .put("indices", org.json.JSONArray())
                .put("offsets", org.json.JSONArray().put(baseOffsets.optDouble(0, 0.0)).put(baseOffsets.optDouble(1, 0.0)))
                .put("fps", org.json.JSONArray().put(22).put(26))
            anims.put(color, anim)
        }
        val config = JSONObject()
            .put("scale", asset.optDouble("scale", 1.0).takeIf { it.isFinite() && it > 0 } ?: 1.0)
            .put("allowRGB", true)
            .put("allowPixel", asset.optBoolean("isPixel", false))
            .put("rgb", JSONObject.NULL)
            .put("animations", anims)
        output.parentFile?.mkdirs()
        output.writeText(config.toString(2))
        return true
    }

    private fun renameRule(outputPrefix: String, asset: JSONObject, animation: JSONObject): RenameRule {
        fun pair(value: Any?): Pair<Double, Double> {
            val a = value as? org.json.JSONArray ?: return 0.0 to 0.0
            return a.optDouble(0, 0.0) to a.optDouble(1, 0.0)
        }
        val base = pair(asset.optJSONArray("offsets"))
        val local = pair(animation.optJSONArray("offsets"))
        val indices = animation.optJSONArray("frameIndices")?.let { a ->
            if (a.length() == 0) null else (0 until a.length()).mapNotNull { a.optInt(it, -1).takeIf { n -> n >= 0 } }.toSet()
        }
        return RenameRule(outputPrefix, base.first + local.first, base.second + local.second, indices)
    }

    private fun resolveStyleChain(root: File, styleId: String, report: (String) -> Unit): List<JSONObject> {
        val result = ArrayList<JSONObject>()
        val visited = HashSet<String>()
        var current = styleId
        var depth = 0
        while (current.isNotBlank() && depth < 8 && visited.add(current.lowercase(Locale.ROOT))) {
            val f = File(root, "data/notestyles/$current.json")
            if (!f.isFile) break
            val data = try { JSONObject(f.readText().removePrefix("\uFEFF")) } catch (e: Exception) {
                report("note style '$current' JSON is invalid: ${e.message}")
                break
            }
            result.add(data)
            current = data.optString("fallback", "").takeIf { it.isNotBlank() && !it.equals("null", true) } ?: break
            depth++
        }
        if (depth >= 8) report("note style '$styleId' fallback chain exceeded 8 levels; remaining parents were ignored")
        return result
    }

    private fun mergeSheets(
        specs: List<Triple<JSONObject, Map<String, RenameRule>, Boolean>>,
        targetBase: File,
        findAsset: (String, String) -> File?,
        report: (String) -> Unit,
        label: String
    ): Boolean {
        val packed = ArrayList<PackedFrame>()
        val usedNames = HashSet<String>()
        try {
            for ((asset, rename, copyAll) in specs) {
                val basePath = asset.optString("assetPath", "").substringAfterLast(':')
                    .removeSuffix(".png").removeSuffix(".xml")
                if (basePath.isBlank()) continue
                val png = findAsset(basePath, ".png")
                val xml = findAsset(basePath, ".xml")
                if (png == null || xml == null) {
                    report("$label: '$basePath' is missing a PNG or Sparrow XML atlas; that asset was not merged")
                    continue
                }
                val image = BitmapFactory.decodeFile(png.path)
                if (image == null) {
                    report("$label: failed to decode '$basePath.png'")
                    continue
                }
                // Psych 1.0.4 scales note/receptor/sustain sprites to 0.7 in its own classes.
                // Pre-compensate here so the final on-screen size matches V-Slice's authored scale.
                val authoredScale = asset.optDouble("scale", 1.0).takeIf { it.isFinite() && it > 0 } ?: 1.0
                val scale = when {
                    label.startsWith("note style") -> authoredScale / 0.7
                    // NoteSplashConfig applies the V-Slice scale at runtime; do not bake it
                    // into the PNG as well or splash effects would be scaled twice.
                    label.startsWith("note splash") -> 1.0
                    else -> authoredScale
                }
                val pixel = asset.optBoolean("isPixel", false)
                val xmlText = xml.readText()
                val tags = Regex("<SubTexture\\b[^>]*?/?>").findAll(xmlText).map { it.value }.toList()
                if (tags.isEmpty()) {
                    image.recycle()
                    report("$label: '$basePath.xml' has no Sparrow SubTexture entries")
                    continue
                }
                val frames = tags.mapNotNull { parseFrame(it) }
                var copiedFromSource = 0
                for (frame in frames) {
                    val destPrefix = if (copyAll) {
                        // Psych 1.0.4's sustain renderer expects these exact prefixes.
                        // V-Slice hold atlases commonly call the source frames holdPiece/holdEnd.
                        if (label.startsWith("note style") && label.contains("note style '")) {
                            val lower = frame.name.lowercase(Locale.ROOT)
                            val suffix = Regex("(\\d+)$").find(frame.name)?.value.orEmpty()
                            val holdKind = when {
                                lower.contains("holdend") || lower.contains("hold_end") || lower.contains("hold end") -> "hold end"
                                lower.contains("holdpiece") || lower.contains("hold_piece") || lower.contains("hold piece") || lower.contains("hold") -> "hold piece"
                                else -> ""
                            }
                            if (holdKind.isNotEmpty()) {
                                val colors = listOf("purple", "blue", "green", "red")
                                // The V-Slice sustain texture is tinted by Psych's note RGB shader.
                                for (color in colors) {
                                    val name = "$color $holdKind$suffix"
                                    if (usedNames.add(name)) {
                                        val crop = cropFrame(image, frame, scale, pixel)
                                        if (crop != null) packed.add(PackedFrame(name, crop,
                                            frame.frameX?.let { (it * scale).roundToInt() },
                                            frame.frameY?.let { (it * scale).roundToInt() },
                                            frame.frameWidth?.let { (it * scale).roundToInt() },
                                            frame.frameHeight?.let { (it * scale).roundToInt() }))
                                    }
                                }
                                copiedFromSource++
                            }
                            null
                        } else frame.name
                    } else null
                    val ruleMatch = if (copyAll) null else rename.entries.firstOrNull { frame.name.startsWith(it.key) }
                    if (!copyAll && ruleMatch == null) continue
                    val rule = ruleMatch?.value
                    val name = if (copyAll) destPrefix else rule!!.outputPrefix + frame.name.removePrefix(ruleMatch!!.key)
                    if (name.isNullOrBlank() || !usedNames.add(name)) continue
                    val suffix = if (ruleMatch != null) frame.name.removePrefix(ruleMatch.key) else ""
                    val sourceFrameIndex = Regex("(\\d+)$").find(suffix)?.value?.toIntOrNull() ?: 0
                    if (rule?.frameIndices != null && sourceFrameIndex !in rule.frameIndices) {
                        usedNames.remove(name)
                        continue
                    }
                    val cropped = cropFrame(image, frame, scale, pixel) ?: continue
                    val offsetX = (rule?.offsetX ?: 0.0) * scale
                    val offsetY = (rule?.offsetY ?: 0.0) * scale
                    val hasOffset = offsetX != 0.0 || offsetY != 0.0
                    val hasFrame = frame.frameX != null || frame.frameY != null || frame.frameWidth != null || frame.frameHeight != null || hasOffset
                    packed.add(PackedFrame(
                        name, cropped,
                        if (hasFrame) (((frame.frameX ?: 0) - offsetX).roundToInt()) else null,
                        if (hasFrame) (((frame.frameY ?: 0) - offsetY).roundToInt()) else null,
                        if (hasFrame) ((frame.frameWidth ?: frame.width) * scale).roundToInt() else null,
                        if (hasFrame) ((frame.frameHeight ?: frame.height) * scale).roundToInt() else null
                    ))
                    copiedFromSource++
                }
                image.recycle()
                if (!copyAll && copiedFromSource == 0) report("$label: no frames matched the configured animation prefixes in '$basePath.xml'")
                if (copyAll && label.startsWith("note style") && copiedFromSource == 0) report("$label: no holdPiece/holdEnd frames were found in '$basePath.xml'")
            }
            if (packed.isEmpty()) return false

            val maxWidth = 2048
            var x = 2; var y = 2; var rowHeight = 0; var usedWidth = 2
            for (frame in packed) {
                val w = frame.bitmap.width; val h = frame.bitmap.height
                if (w + 4 > maxWidth) {
                    report("$label: a frame is wider than the 2048-pixel atlas limit")
                    packed.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
                    return false
                }
                if (x + w + 2 > maxWidth) { x = 2; y += rowHeight + 2; rowHeight = 0 }
                frame.outX = x; frame.outY = y
                x += w + 2; rowHeight = maxOf(rowHeight, h); usedWidth = maxOf(usedWidth, x)
            }
            val usedHeight = y + rowHeight + 2
            if (usedHeight > 4096) {
                report("$label: merged atlas exceeds the 2048x4096 safe packing limit")
                packed.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
                return false
            }
            val outW = nextPowerOfTwo(usedWidth.coerceAtLeast(4)).coerceAtMost(maxWidth)
            val outH = nextPowerOfTwo(usedHeight.coerceAtLeast(4)).coerceAtMost(4096)
            val sheet = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(sheet)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            for (frame in packed) canvas.drawBitmap(frame.bitmap, frame.outX.toFloat(), frame.outY.toFloat(), paint)
            targetBase.parentFile?.mkdirs()
            targetBase.outputStream().buffered().use { sheet.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val xmlOut = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<TextureAtlas imagePath=\"${xmlEscape(targetBase.name)}.png\">\n")
            for (frame in packed) {
                xmlOut.append("\t<SubTexture name=\"${xmlEscape(frame.name)}\" x=\"${frame.outX}\" y=\"${frame.outY}\" width=\"${frame.bitmap.width}\" height=\"${frame.bitmap.height}\"")
                if (frame.frameX != null) xmlOut.append(" frameX=\"${frame.frameX}\"")
                if (frame.frameY != null) xmlOut.append(" frameY=\"${frame.frameY}\"")
                if (frame.frameWidth != null) xmlOut.append(" frameWidth=\"${frame.frameWidth}\"")
                if (frame.frameHeight != null) xmlOut.append(" frameHeight=\"${frame.frameHeight}\"")
                xmlOut.append("/>\n")
            }
            xmlOut.append("</TextureAtlas>\n")
            File(targetBase.path + ".xml").writeText(xmlOut.toString())
            sheet.recycle()
            packed.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
            return true
        } catch (e: OutOfMemoryError) {
            packed.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
            report("$label: not enough memory to merge the sprite sheets on this device")
            return false
        } catch (e: Exception) {
            packed.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
            report("$label: atlas merge failed safely: ${e.message}")
            return false
        }
    }

    private fun cropFrame(image: Bitmap, frame: SourceFrame, scale: Double, pixel: Boolean): Bitmap? {
        if (frame.x < 0 || frame.y < 0 || frame.width < 1 || frame.height < 1 ||
            frame.x + frame.width > image.width || frame.y + frame.height > image.height ||
            frame.width > 2048 || frame.height > 2048) return null
        var cropped = Bitmap.createBitmap(image, frame.x, frame.y, frame.width, frame.height)
        if (scale != 1.0) {
            val sw = (cropped.width * scale).roundToInt().coerceAtLeast(1)
            val sh = (cropped.height * scale).roundToInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(cropped, sw, sh, !pixel)
            if (scaled !== cropped) cropped.recycle()
            cropped = scaled
        }
        return cropped
    }

    private fun parseFrame(tag: String): SourceFrame? {
        val attrs = Regex("([A-Za-z_:][A-Za-z0-9_:.-]*)=\"([^\"]*)\"").findAll(tag).associate { it.groupValues[1] to it.groupValues[2] }
        val name = attrs["name"] ?: return null
        if (attrs["rotated"]?.equals("true", true) == true) return null
        fun int(key: String) = attrs[key]?.toDoubleOrNull()?.roundToInt()
        return SourceFrame(name, int("x") ?: return null, int("y") ?: return null,
            int("width") ?: return null, int("height") ?: return null,
            int("frameX"), int("frameY"), int("frameWidth"), int("frameHeight"))
    }

    private fun nextPowerOfTwo(value: Int): Int {
        if (value <= 1) return 1
        return 2.0.pow(ceil(ln(value.toDouble()) / ln(2.0))).toInt()
    }

    private fun xmlEscape(s: String): String = s.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;")
}
