package com.portyou.studio.convert

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Line-by-line port of tools/fnmm_to_psych.py (the verified reference implementation). */
class FunkyMakerConverter(private val ctx: Context) {
    private val dirs = listOf("idle", "singLEFT", "singDOWN", "singUP", "singRIGHT", "miss", "special")
    private val xmlp = listOf("idle_", "left_", "down_", "up_", "right_", "miss_", "special_")
    private val baseFps = 10.0
    private val catalog = setOf("ScreenFlash", "CameraShake", "CameraSet", "BarIconChange", "ObjectSpriteSet", "ObjectChartChange",
        "ObjectAnimationSet", "ObjectVisibilitySet", "ObjectOpacitySet", "PlayerHealth", "RunActionPack", "GUI",
        "ObjectBlendColor", "CameraZoom", "ObjectPositionSet")

    private fun slug(s: String): String {
        val r = s.lowercase().replace(Regex("[^a-z0-9_-]+"), "-").trim('-')
        return if (r.count { it.isLetterOrDigit() } >= 2) r else "fnmm-mod"
    }
    private fun lua(s: String) = "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'"
    private fun num(d: Double) = if (d == Math.floor(d) && Math.abs(d) < 1e12) d.toLong().toString() else d.toString()
    private fun rd(f: File) = JSONObject(f.readText().removePrefix("\uFEFF").trim())
    private fun save(b: Bitmap, f: File) {
        f.parentFile?.mkdirs()
        f.outputStream().buffered().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    private class Strip(val a: JSONObject, val img: Bitmap)

    // scene.json exists in two layouts: old (flat x / y / scale{x,y}) and v4 (transform[0].position{x,y} / scale{x,y}, cameras[].position{x,y})
    private fun tf(o: JSONObject): JSONObject = o.optJSONArray("transform")?.optJSONObject(0) ?: o
    private fun px(o: JSONObject): Double { val t = tf(o); return t.optJSONObject("position")?.optDouble("x", 0.0) ?: t.optDouble("x", 0.0) }
    private fun py(o: JSONObject): Double { val t = tf(o); return t.optJSONObject("position")?.optDouble("y", 0.0) ?: t.optDouble("y", 0.0) }
    private fun sx(o: JSONObject): Double { val s = tf(o).opt("scale"); return when (s) { is JSONObject -> s.optDouble("x", 1.0); is Number -> s.toDouble(); else -> 1.0 } }
    private fun sy(o: JSONObject): Double { val s = tf(o).opt("scale"); return when (s) { is JSONObject -> s.optDouble("y", s.optDouble("x", 1.0)); is Number -> s.toDouble(); else -> 1.0 } }
    private fun scrollX(o: JSONObject): Double = tf(o).optJSONObject("scrollFactor")?.optDouble("x", 1.0) ?: 1.0
    private fun scrollY(o: JSONObject): Double = tf(o).optJSONObject("scrollFactor")?.optDouble("y", 1.0) ?: 1.0
    private fun camX(c: JSONObject): Double = c.optJSONObject("position")?.optDouble("x", 1080.0) ?: c.optDouble("x", 1080.0)
    private fun camY(c: JSONObject): Double = c.optJSONObject("position")?.optDouble("y", 960.0) ?: c.optDouble("y", 960.0)

    fun convert(root: File, outRoot: File, originalName: String, report: MutableList<String>): String {
        val data = rd(File(root, "data.json")); val scene = rd(File(root, "scene.json"))
        val events = File(root, "events.json").takeIf { it.isFile }?.let { try { rd(it) } catch (_: Exception) { JSONObject() } } ?: JSONObject()
        val name = slug(originalName.substringBeforeLast('.'))
        val song = name
        val out = File(outRoot, name).also { it.deleteRecursively(); it.mkdirs() }
        fun P(vararg p: String) = File(out, p.joinToString("/"))
        val bpm = data.optDouble("bpm", 120.0)
        val beatMs = 60000.0 / bpm; val secMs = beatMs * 4

        // ---------- chart ----------
        class N(val ms: Double, val d: Int, val len: Double, val type: String)
        val notes = ArrayList<N>(); var last = 0.0
        val noteTypes = LinkedHashMap<String, Triple<Int, Int, Int>>(); val noteTypeCount = HashMap<String, Int>()
        val sls = data.getJSONArray("strumLines")
        // psych_v1 = ABSOLUTE lanes: 0-3 player, 4-7 opponent. strumLine 0 = player, 1 = opponent, 2+ = girlfriend ('GF Sing' on the opponent side).
        for (sl in 0 until sls.length()) {
            val lanes = sls.getJSONArray(sl)
            for (lane in 0 until min(4, lanes.length())) {
                val lst = lanes.getJSONArray(lane)
                for (i in 0 until lst.length()) {
                    val n = lst.getJSONObject(i)
                    val ms = n.getDouble("start") * 1000.0
                    var ln = n.optDouble("duration", 0.0) * 1000.0
                    if (ln < beatMs / 8) ln = 0.0
                    // note props: skin (arrow style), onPressEvent / onMissEvent (action pack index) -> a Psych note type
                    val pr = n.optJSONObject("props")
                    val skin = pr?.optDouble("skin", 0.0)?.toInt() ?: 0
                    val onP = pr?.optDouble("onPressEvent", -1.0)?.toInt() ?: -1
                    val onM = pr?.optDouble("onMissEvent", -1.0)?.toInt() ?: -1
                    val tname = when {
                        sl >= 2 -> "GF Sing"
                        skin == 0 && onP < 0 && onM < 0 -> ""
                        skin >= 2 && onP < 0 && onM < 0 -> "Hurt Note"      // Psych's own hurt note (skin >= 2 with no action = trap arrow)
                        else -> "fnmm-s$skin" + (if (onP >= 0) "-p$onP" else "") + (if (onM >= 0) "-m$onM" else "")
                    }
                    if (tname.startsWith("fnmm-")) noteTypes[tname] = Triple(skin, onP, onM)
                    noteTypeCount[tname] = (noteTypeCount[tname] ?: 0) + 1
                    notes.add(N(ms, lane + (if (sl == 0) 0 else 4), ln, tname)); last = max(last, ms + ln)
                }
            }
        }
        val nsec = (last / secMs).toInt() + 2
        val secs = Array(nsec) { JSONObject().put("sectionNotes", JSONArray()).put("sectionBeats", 4).put("mustHitSection", true)
            .put("gfSection", false).put("bpm", bpm).put("changeBPM", false) }
        for (n in notes.sortedWith(compareBy({ it.ms }, { it.d }))) secs[(n.ms / secMs).toInt()].getJSONArray("sectionNotes").put(JSONArray().put(n.ms).put(n.d).put(n.len).put(n.type))
        val objs = scene.getJSONArray("objects")
        val charObj = HashMap<Int, Int>()
        for (i in 0 until objs.length()) { val sl = objs.getJSONObject(i).optDouble("strumLine", -1.0).toInt(); if ((sl == 0 || sl == 1) && sl !in charObj) charObj[sl] = i }
        P("data", song, "$song.json").also { it.parentFile?.mkdirs() }.writeText(JSONObject()
            .put("song", song).put("notes", JSONArray(secs.toList())).put("bpm", bpm).put("needsVoices", false).put("speed", 2.5).put("offset", 0)
            .put("player1", "fnmm-player").put("player2", if (1 in charObj) "fnmm-enemy" else "bf").put("gfVersion", "gf").put("stage", name).put("events", JSONArray())
            .put("format", "psych_v1").put("arrowSkin", "").put("splashSkin", "noteSplashes/noteSplashes").toString(1))

        // ---------- sprites ----------
        val spr = HashMap<String, JSONObject>()
        File(root, "sprites").listFiles()?.filter { File(it, "sprite.json").isFile }?.forEach { spr[it.name] = rd(File(it, "sprite.json")) }
        fun strips(sn: String): List<Strip> {
            val d = spr[sn]!!.getJSONArray("data")
            return (0 until d.length()).map { Strip(d.getJSONObject(it), BitmapFactory.decodeFile(File(root, "sprites/$sn/$it.png").path)) }
        }
        fun numOf(a: JSONObject) = max(1, a.get("num").toString().toDouble().toInt())
        fun frames(s: Strip): List<Bitmap> { val n = numOf(s.a); val fw = s.img.width / n; return (0 until n).map { Bitmap.createBitmap(s.img, it * fw, 0, fw, s.img.height) } }
        fun fps(a: JSONObject) = if (a.optBoolean("spd_fps")) a.getDouble("spd") else a.getDouble("spd") * baseFps

        class CharInfo(val stageX: Double, val stageY: Double, val scale: Double, val scaleX: Double, val scaleY: Double)
        val chars = HashMap<String, CharInfo>()
        val charScaleTables = ArrayList<String>()
        for ((sl, key) in listOf(0 to "fnmm-player", 1 to "fnmm-enemy")) {
            val oi = charObj[sl] ?: continue
            val o = objs.getJSONObject(oi); val transformScaleX = sx(o); val transformScaleY = sy(o)
            val sn = o.getString("spr")
            val st = strips(sn)
            val fr = st.map { frames(it) }
            val pres = st.indices.map { if (it < xmlp.size) xmlp[it] else "extra${it}_" }
            val cw = fr.maxOf { l -> l.maxOf { it.width } }; val chh = fr.maxOf { l -> l.maxOf { it.height } }
            val flat = ArrayList<Triple<Int, Int, Bitmap>>()
            for ((ai, l) in fr.withIndex()) for ((i, f) in l.withIndex()) flat.add(Triple(ai, i, f))

            // One complete atlas per character. Never split a large character into pages.
            val cols = max(1, kotlin.math.ceil(kotlin.math.sqrt(flat.size.toDouble())).toInt())
            val rows = max(1, ceil(flat.size / cols.toDouble()).toInt())
            val sheet = Bitmap.createBitmap(cols * cw, rows * chh, Bitmap.Config.ARGB_8888)
            val cv = Canvas(sheet)
            val xml = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<TextureAtlas imagePath=\"$key.png\">\n")
            for ((n, t) in flat.withIndex()) {
                val x = (n % cols) * cw; val y = (n / cols) * chh; val frameName = "%04d".format(t.second)
                cv.drawBitmap(t.third, (x + (cw - t.third.width) / 2).toFloat(), (y + (chh - t.third.height) / 2).toFloat(), null)
                xml.append("\t<SubTexture name=\"${pres[t.first]}$frameName\" x=\"$x\" y=\"$y\" width=\"$cw\" height=\"$chh\"/>\n")
                t.third.recycle()
            }
            xml.append("</TextureAtlas>")
            save(sheet, P("images", "characters", "$key.png"))
            P("images", "characters", "$key.xml").also { it.parentFile?.mkdirs() }.writeText(xml.toString())
            sheet.recycle()

            val baseOffset = st.firstOrNull()?.a?.optJSONObject("offset") ?: JSONObject()
            val baseOx = baseOffset.optDouble("x", cw / 2.0)
            val baseOy = baseOffset.optDouble("y", chh / 2.0)
            val baseAnimScale = st.firstOrNull()?.a?.optDouble("scale", 1.0) ?: 1.0
            val anims = JSONArray()
            val scales = ArrayList<String>()
            for ((i, strip) in st.withIndex()) {
                val a = strip.a
                val off = a.optJSONObject("offset") ?: JSONObject()
                val ox = off.optDouble("x", cw / 2.0); val oy = off.optDouble("y", chh / 2.0)
                val animScale = a.optDouble("scale", 1.0)
                val actualScaleX = transformScaleX * animScale
                val actualScaleY = transformScaleY * animScale
                // Psych's animation offset shifts the sprite from the first animation's pivot.
                val dx = (ox * animScale - baseOx * baseAnimScale) * transformScaleX
                val dy = (oy * animScale - baseOy * baseAnimScale) * transformScaleY
                fun anim(nm: String) = JSONObject().put("loop", a.optBoolean("loop", true)).put("offsets", JSONArray().put(dx).put(dy))
                    .put("anim", nm).put("fps", fps(a).roundToInt().coerceAtLeast(1)).put("name", pres[i]).put("indices", JSONArray())
                val animName = if (i < dirs.size) dirs[i] else "extra$i"
                anims.put(anim(animName))
                if (animName == "miss") for (direction in listOf("LEFT", "DOWN", "UP", "RIGHT")) anims.put(anim("sing${direction}miss"))
                scales.add("{${num(actualScaleX)}, ${num(actualScaleY)}}")
            }
            val baseScaleX = transformScaleX * baseAnimScale
            val baseScaleY = transformScaleY * baseAnimScale
            val anchorX = px(o); val anchorY = py(o)
            chars[key] = CharInfo(anchorX - baseOx * baseScaleX, anchorY - baseOy * baseScaleY, baseScaleX, baseScaleX, baseScaleY)
            P("characters", "$key.json").also { it.parentFile?.mkdirs() }.writeText(JSONObject().put("animations", anims).put("vocals_file", "")
                .put("no_antialiasing", false).put("image", "characters/$key").put("position", JSONArray().put(0).put(0)).put("healthicon", key)
                .put("flip_x", sl == 0).put("healthbar_colors", if (sl == 0) JSONArray("[252,252,4]") else JSONArray("[252,4,108]"))
                .put("camera_position", JSONArray().put(0).put(0)).put("sing_duration", 4).put("scale", baseScaleX).put("_editor_isPlayer", sl == 0).toString(1))
            charScaleTables.add("[${oi}]={${scales.joinToString(",")}}")
            st.forEach { if (!it.img.isRecycled) it.img.recycle() }
        }
        // Psych health icons are two-frame atlases, one per actual character slot.
        // Do not emit an extra generic icon for every type-3 sprite in the scene.
        val icons = scene.optJSONArray("icons") ?: JSONArray()
        for (i in 0 until min(2, icons.length())) {
            val sn = icons.optString(i, "")
            val sj = spr.optJSONObject(sn) ?: continue
            if (sj.optInt("type", -1) != 3) continue
            val iconStrips = strips(sn).take(2)
            val fr = iconStrips.map { it.img }.toMutableList(); if (fr.isEmpty()) continue
            while (fr.size < 2) fr.add(fr[0])
            val w = fr.maxOf { it.width }; val h = fr.maxOf { it.height }
            val sh = Bitmap.createBitmap(w * 2, h, Bitmap.Config.ARGB_8888); val cv = Canvas(sh)
            fr.forEachIndexed { j, f -> cv.drawBitmap(f, (j * w).toFloat(), 0f, null) }
            save(sh, P("images", "icons", "icon-${if (i == 0) "fnmm-player" else "fnmm-enemy"}.png"))
            sh.recycle()
            iconStrips.forEach { if (!it.img.isRecycled) it.img.recycle() }
        }
        // world objects + sprite registry (types 0 and 2 are plain strips)
        val saved = HashSet<String>()
        fun animLua(sn: String): String = strips(sn).withIndex().joinToString(", ") { (k, s) ->
            val n = numOf(s.a)
            if (saved.add("$sn$k")) save(s.img, P("images", name, "${sn}_$k.png"))
            val off = s.a.optJSONObject("offset") ?: JSONObject()
            val colorScale = s.a.optDouble("scale", 1.0)
            val result = "{img=${lua("$name/${sn}_$k")}, fw=${s.img.width / n}, fh=${s.img.height}, frames=$n, fps=${num(fps(s.a))}, loop=${s.a.optBoolean("loop", true)}, ox=${num(off.optDouble("x", (s.img.width / n) / 2.0))}, oy=${num(off.optDouble("y", s.img.height / 2.0))}, sx=${num(colorScale)}, sy=${num(colorScale)}}"
            if (!s.img.isRecycled) s.img.recycle()
            result
        }
        val objLua = ArrayList<String>()
        for (i in 0 until objs.length()) {
            val o = objs.getJSONObject(i); val sn = o.getString("spr")
            if (i in charObj.values || sn !in spr) continue
            val col = o.optJSONObject("color") ?: JSONObject()
            val colorHex = "%02X%02X%02X".format(col.optDouble("r", 255.0).toInt().coerceIn(0,255), col.optDouble("g", 255.0).toInt().coerceIn(0,255), col.optDouble("b", 255.0).toInt().coerceIn(0,255))
            objLua.add("\t{idx=$i, spr=${lua(sn)}, cx=${num(px(o))}, cy=${num(py(o))}, scaleX=${num(sx(o))}, scaleY=${num(sy(o))}, " +
                "scrollX=${num(scrollX(o))}, scrollY=${num(scrollY(o))}, alpha=${num(o.optDouble("opacity", 1.0))}, color=${lua(colorHex)}, " +
                "visible=${o.optBoolean("visible", true)}, fixed=${o.optBoolean("fixed", false)}, anims={${animLua(sn)}}},")
        }
        val sprLua = spr.filter { it.value.getDouble("type").toInt() in listOf(0, 2) }.map { "\t[${lua(it.key)}] = {${animLua(it.key)}}," }

        // ---------- stage ----------
        val cams = scene.optJSONArray("cameras") ?: JSONArray("[{\"x\":1080,\"y\":960,\"scale\":1}]")
        val cam = cams.getJSONObject(0)
        fun tl(sl: Int): JSONArray { val c = chars[if (sl == 0) "fnmm-player" else "fnmm-enemy"] ?: return JSONArray().put(0).put(0)
            return JSONArray().put(c.stageX).put(c.stageY) }
        P("stages", "$name.json").also { it.parentFile?.mkdirs() }.writeText(JSONObject().put("directory", "").put("stageUI", "normal").put("defaultZoom", cam.optDouble("scale", 1.0) * 0.7)
            .put("isPixelStage", false).put("boyfriend", tl(0)).put("girlfriend", JSONArray("[400,130]")).put("opponent", tl(1)).put("hide_girlfriend", true)
            .put("camera_boyfriend", JSONArray("[0,0]")).put("camera_opponent", JSONArray("[0,0]")).put("camera_girlfriend", JSONArray("[0,0]")).put("camera_speed", 100).toString(1))

        // ---------- events (every FNMM action -> [Type, "k=v;k=v", ""]) ----------
        val packs = events.optJSONArray("action_packs") ?: JSONArray(); val unknown = sortedSetOf<String>()
        fun flat(p: JSONObject, pre: String = ""): List<String> = p.keys().asSequence().flatMap { k ->
            val v = p.get(k)
            if (v is JSONObject) flat(v, "$pre$k.").asSequence() else sequenceOf("$pre$k=" + (if (v is Double && v == Math.floor(v)) v.toLong().toString()
                else if (v is Boolean) (if (v) "1" else "0") else v.toString()).replace(";", ","))
        }.toList()
        fun expand(actions: JSONArray, depth: Int, outl: MutableList<JSONArray>) {
            for (i in 0 until actions.length()) {
                val a = actions.getJSONObject(i); val t = a.getString("type"); val p = a.optJSONObject("props") ?: JSONObject()
                if (t == "RunActionPack") { val pi = p.optDouble("actionPack", 0.0).toInt(); if (depth < 8 && pi in 0 until packs.length()) expand(packs.getJSONObject(pi).getJSONArray("actions"), depth + 1, outl); continue }
                if (t !in catalog) unknown.add(t)
                outl.add(JSONArray().put(t).put(flat(p).joinToString(";")).put(""))
            }
        }
        val evl = ArrayList<Pair<Double, List<JSONArray>>>(); val used = sortedSetOf<String>()
        val evs = events.optJSONArray("events") ?: JSONArray()
        for (i in 0 until evs.length()) {
            val ev = evs.getJSONObject(i); val row = ArrayList<JSONArray>(); expand(ev.optJSONArray("actions") ?: JSONArray(), 0, row)
            if (row.isNotEmpty()) { evl.add(ev.getDouble("time") * 1000.0 to row); row.forEach { used.add(it.getString(0)) } }
        }
        evl.sortBy { it.first }
        val evJson = JSONArray(); for ((t, r) in evl) evJson.put(JSONArray().put(t).put(JSONArray(r)))
        // events live INSIDE the chart (a chart without an "events" key = Null Object Reference in PlayState.generateSong)
        val chartFile = P("data", song, "$song.json")
        chartFile.writeText(JSONObject(chartFile.readText()).put("events", evJson).toString(1))
        for (t in used) P("custom_events", "$t.txt").also { it.parentFile?.mkdirs() }.writeText("FNMM $t (executed by scripts/fnmm_runtime.lua)")
        if (unknown.isNotEmpty()) report.add("Unknown FNMM actions kept as events (manual work needed): " + unknown.joinToString())

        // ---------- note types (skin / onPress / onMiss) ----------
        for ((tn, tr) in noteTypes) {
            val (skin, onP, onM) = tr
            fun calls(pi: Int): String {
                if (pi < 0 || pi >= packs.length()) return ""
                val rows = ArrayList<JSONArray>(); expand(packs.getJSONObject(pi).getJSONArray("actions"), 0, rows)
                return rows.joinToString("") { "\t\ttriggerEvent(${lua(it.getString(0))}, ${lua(it.getString(1))}, '')\n" }
            }
            val q = lua(tn)
            val lu = StringBuilder("-- PortYou: Funky Maker note (skin $skin, onPress pack $onP, onMiss pack $onM)\n")
            lu.append("function goodNoteHit(id, noteData, noteType, isSustainNote)\n\tif noteType == $q and not isSustainNote then\n").append(calls(onP)).append("\tend\nend\n")
            lu.append("function noteMiss(id, noteData, noteType, isSustainNote)\n\tif noteType == $q and not isSustainNote then\n").append(calls(onM)).append("\tend\nend\n")
            P("custom_notetypes", "$tn.lua").also { it.parentFile?.mkdirs() }.writeText(lu.toString())
        }
        if (noteTypeCount.keys.any { it.isNotEmpty() && it != "GF Sing" })
            report.add("Funky Maker notes with special props: " + noteTypeCount.filterKeys { it.isNotEmpty() && it != "GF Sing" }.entries.joinToString { "${it.key} x${it.value}" } +
                " (skin >= 2 without any action was treated as a hurt note)")

        // ---------- runtime ----------
        val camsLua = (0 until cams.length()).joinToString(", ") { val c = cams.getJSONObject(it); "{${num(camX(c))}, ${num(camY(c))}, ${num(c.optDouble("scale", 1.0))}}" }
        val rt = ctx.assets.open("converter/fnmm_runtime.lua").bufferedReader().readText()
            .replace("--[[CAMS]]", camsLua).replace("--[[OBJS]]", objLua.joinToString("\n")).replace("--[[SPRS]]", sprLua.joinToString("\n"))
            .replace("--[[CHAROBJ]]", "local CHAR_OBJ = {[0]=${charObj[0] ?: -1}, [1]=${charObj[1] ?: -1}}")
            .replace("--[[CHAR_SCALES]]", "local CHAR_ANIM_SCALES = {${charScaleTables.joinToString(",")}}")
        P("scripts", "fnmm_runtime.lua").also { it.parentFile?.mkdirs() }.writeText(rt)

        // ---------- week / pack / audio ----------
        P("weeks", "$name.json").also { it.parentFile?.mkdirs() }.writeText(JSONObject().put("songs", JSONArray().put(JSONArray().put(song).put(if (1 in charObj) "fnmm-enemy" else "bf").put(JSONArray("[252,4,108]"))))
            .put("weekCharacters", JSONArray("[\"\",\"bf\",\"gf\"]")).put("weekBackground", "").put("weekBefore", "tutorial").put("storyName", name).put("weekName", name)
            .put("startUnlocked", true).put("hideStoryMode", true).put("hideFreeplay", false).put("difficulties", "Normal").toString(1))
        Credits.write(ctx, out, name, intArrayOf(252, 4, 108))
        val audioFiles = root.walkTopDown().filter { it.isFile && it.extension.lowercase() in listOf("ogg", "mp3", "wav") }.sortedBy { it.relativeTo(root).path.lowercase() }.toList()
        val songDir = P("songs", song).also { it.mkdirs() }
        val inst = audioFiles.firstOrNull { it.name.equals("Inst.ogg", true) || it.name.equals("instrumental.ogg", true) }
            ?: audioFiles.firstOrNull { it.name.equals("music.ogg", true) }
            ?: audioFiles.firstOrNull { it.parentFile == root && it.name.startsWith("music", true) }
        if (inst != null) inst.copyTo(File(songDir, "Inst.ogg"), overwrite = true)
        else report.add("No instrumental/music.ogg was found; songs/$song/Inst.ogg was not fabricated.")
        val vocal = audioFiles.filter { it != inst && it.name.startsWith("Voices", true) }
        for ((i, f) in vocal.withIndex()) {
            val destName = when {
                f.name.equals("Voices.ogg", true) -> "Voices.ogg"
                f.name.startsWith("Voices-", true) -> f.name
                i == 0 -> "Voices.ogg"
                else -> "Voices-extra$i.${f.extension.lowercase()}"
            }
            f.copyTo(File(songDir, destName), overwrite = true)
        }
        // Preserve stage SFX, ambience and videos in their engine folders. Never let them
        // overwrite Inst.ogg just because their filename begins with "music".
        for (folder in listOf("sounds", "music", "videos")) {
            val srcDir = File(root, folder)
            if (srcDir.isDirectory) srcDir.copyRecursively(P(folder), overwrite = true)
        }
        for (f in audioFiles) {
            if (f == inst || f in vocal) continue
            val rel = f.relativeTo(root).invariantSeparatorsPath
            if (rel.substringBefore('/') in listOf("sounds", "music", "videos")) continue
            val dest = if (f.parentFile == root) P("sounds", f.name) else P("audio", "extra", rel)
            dest.parentFile?.mkdirs(); f.copyTo(dest, overwrite = true)
        }
        ImagePost.run(out, report)
        return name
    }
}
