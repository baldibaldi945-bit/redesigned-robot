package com.portyou.studio.convert

import org.json.JSONObject
import java.io.File

/**
 * Kotlin port of tools/portyou/hx2lua.py: Haxe (.hx/.hxc, V-Slice + HScript style) -> Psych Engine Lua, PER FUNCTION.
 * A function that cannot be translated with certainty is not guessed: it is reported and left out.
 * Rules come from assets/converter/methods.json ("haxe"), the same file the Python tool uses.
 */
class Hx2Lua(methodsJson: String) {
    class Unconvertible(msg: String) : Exception(msg)
    class Failure(val file: String, val fn: String, val why: String, val code: String)
    class Result { val failed = ArrayList<Failure>(); var ok = 0 }
    class HxFile(val path: File, val kind: String, val event: String?)

    private val kb = JSONObject(methodsJson).optJSONObject("haxe") ?: JSONObject()
    private val callbacks = HashMap<String, String>().also { m -> kb.optJSONObject("callbacks")?.let { o -> o.keys().forEach { k -> m[k.trim()] = o.getString(k) } } }
    private val apiRules = ArrayList<Pair<Regex, String>>()
    private val unsupported = ArrayList<Pair<Regex, String>>()

    init {
        kb.optJSONArray("api_rules")?.let { for (i in 0 until it.length()) { val r = it.getJSONArray(i); apiRules.add(Regex(r.getString(0)) to r.getString(1)) } }
        kb.optJSONArray("unsupported")?.let { for (i in 0 until it.length()) { val r = it.getJSONArray(i); unsupported.add(Regex(r.getString(0)) to r.getString(1)) } }
    }

    // ------------------------------------------------------------------ lexical helpers
    private fun stripComments(src: String): String {
        val out = StringBuilder(); var i = 0; val n = src.length; var q: Char? = null
        while (i < n) {
            val c = src[i]
            if (q != null) {
                out.append(c)
                if (c == '\\' && i + 1 < n) { out.append(src[i + 1]); i += 2; continue }
                if (c == q) q = null
                i++; continue
            }
            if (c == '"' || c == '\'') { q = c; out.append(c); i++; continue }
            if (src.startsWith("//", i)) { while (i < n && src[i] != '\n') i++; continue }
            if (src.startsWith("/*", i)) { val j = src.indexOf("*/", i + 2); i = if (j < 0) n else j + 2; continue }
            out.append(c); i++
        }
        return out.toString()
    }

    private fun matchBrace(src: String, start: Int): Int {
        var i = start; var d = 0; var q: Char? = null; val n = src.length
        while (i < n) {
            val c = src[i]
            if (q != null) {
                if (c == '\\') { i += 2; continue }
                if (c == q) q = null
            } else if (c == '"' || c == '\'') q = c
            else if (c == '{') d++
            else if (c == '}') { d--; if (d == 0) return i }
            i++
        }
        throw Unconvertible("unbalanced braces")
    }

    private sealed class Member {
        class Fn(val name: String, val args: String, val body: String) : Member()
        class Var(val text: String) : Member()
    }

    private val fre = Regex("(?:(?:override|public|private|static|inline)\\s+)*function\\s+(\\w+)\\s*\\(([^)]*)\\)\\s*(?::\\s*[\\w.<>]+)?\\s*\\{")
    private val vre = Regex("(?:(?:public|private|static|inline)\\s+)*(?:var|final)\\s+[^;{]*;")

    private fun splitMembers(source: String): List<Member> {
        val src = stripComments(source)
        var body = src
        Regex("\\bclass\\s+\\w+[^{]*\\{").find(src)?.let { m -> val end = matchBrace(src, m.range.last); body = src.substring(m.range.last + 1, end) }
        val members = ArrayList<Member>(); var i = 0
        while (i < body.length) {
            val f = fre.find(body, i); val v = vre.find(body, i)
            if (f != null && (v == null || f.range.first < v.range.first)) {
                val end = matchBrace(body, f.range.last)
                members.add(Member.Fn(f.groupValues[1], f.groupValues[2], body.substring(f.range.last + 1, end)))
                i = end + 1
            } else if (v != null) { members.add(Member.Var(v.value)); i = v.range.last + 1 } else break
        }
        return members
    }

    // ------------------------------------------------------------------ expressions
    private val strRx = Regex("\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*'")
    private val leftRx = Regex("\\b(?:game|FlxG|Flx[A-Z]\\w*|Paths|ClientPrefs|PlayState|Conductor)\\.\\w+")

    private fun expand(rep: String, m: MatchResult): String =
        Regex("\\\\(\\d)").replace(rep) { g -> m.groupValues.getOrElse(g.groupValues[1].toInt()) { "" } }

    private fun convExpr(src: String): String {
        var e = src.trim()
        for ((rx, why) in unsupported) if (rx.containsMatchIn(e)) throw Unconvertible(why)
        val strs = ArrayList<String>()
        e = strRx.replace(e) { m -> strs.add(m.value); "\u0000${strs.size - 1}\u0000" }
        for ((rx, rep) in apiRules) e = rx.replace(e) { m -> expand(rep, m) }
        e = Regex("\\bnull\\b").replace(e, "nil")
        e = e.replace("!=", "~=").replace("&&", " and ").replace("||", " or ")
        e = Regex("!(?!=)\\s*").replace(e, "not ")
        e = Regex("\\bthis\\.").replace(e, "")
        e = Regex(":\\s*(?:Int|Float|String|Bool|Dynamic|Array<\\w+>)\\b").replace(e, "")
        e = Regex("\\bStd\\.int\\(([^()]*)\\)").replace(e) { "math.floor(${it.groupValues[1]})" }
        e = Regex("\\bMath\\.(floor|ceil|abs|sin|cos|sqrt|min|max|random|pow)\\b").replace(e) { "math." + it.groupValues[1] }
        e = Regex("\\bMath\\.PI\\b").replace(e, "math.pi")
        e = Regex("\\bMath\\.round\\(([^()]*)\\)").replace(e) { "math.floor((${it.groupValues[1]}) + 0.5)" }
        e = Regex("\\b(\\w+)\\.length\\b").replace(e) { "#" + it.groupValues[1] }
        e = Regex("\\bmath\\.pow\\(([^,()]+),\\s*([^()]+)\\)").replace(e) { "(${it.groupValues[1]} ^ ${it.groupValues[2]})" }
        if (e.contains('\u0000')) {      // '+' next to a string literal is concatenation
            e = Regex("(\u0000\\d+\u0000)\\s*\\+").replace(e) { it.groupValues[1] + " .." }
            e = Regex("\\+\\s*(\u0000\\d+\u0000)").replace(e) { ".. " + it.groupValues[1] }
            e = Regex("\\.\\.\\s*(\\w[\\w.\\[\\]()]*)\\s*\\+\\s*(?=\u0000|\\w)").replace(e) { ".. ${it.groupValues[1]} .. " }
        }
        if (Regex("\\[\\s*\\]").matches(e)) e = "{}"
        if (Regex("\\[[^\\]]*\\]").matches(e) && !Regex("\\w\\[").containsMatchIn(e)) e = "{" + e.substring(1, e.length - 1) + "}"
        for ((i, sx) in strs.withIndex()) e = e.replace("\u0000$i\u0000", sx)
        val bare = strRx.replace(e, "")
        leftRx.find(bare)?.let { throw Unconvertible("engine API without a Lua equivalent yet: " + it.value) }
        // ---- generic guards: anything left here is NOT valid Psych Lua, so it must never be written into a script
        run {
            val masked = bare   // string literals removed
            if (masked.contains('?')) throw Unconvertible("ternary / null-safe operator")
            Regex("(?<![\\w.])(?!(?:math|string|table|os)\\b)[A-Z][A-Za-z0-9_]*\\.[A-Za-z_]\\w*").find(masked)?.let { throw Unconvertible("engine class API without a Lua equivalent yet: " + it.value) }
            Regex("\\b(?!(?:table|string|math|os)\\b)\\w+\\)?\\.(?:get|set|getBool|getFloat|getInt|getString|push|pop|add|remove|indexOf|exists|keys|playAnimation|flush|contains|copy|join|split|substr|charAt|toString)\\(").find(masked)?.let { throw Unconvertible("object method call has no Psych Lua equivalent: " + it.value) }
        }
        if (e.contains("=>") || e.contains("->") || Regex("\\bnew\\s+\\w").containsMatchIn(e)) throw Unconvertible("lambda / constructor / map literal")
        return e.trim()
    }

    private fun convBlock(body: String, indent: Int = 1): List<String> {
        val out = ArrayList<String>()
        for (st in splitStatements(body)) out += convStmt(st.trim(), indent)
        return out
    }

    private fun splitStatements(body: String): List<String> {
        val res = ArrayList<String>(); var cur = StringBuilder(); var d = 0; var q: Char? = null; var i = 0; val n = body.length
        while (i < n) {
            val c = body[i]
            if (q != null) {
                cur.append(c)
                if (c == '\\' && i + 1 < n) { cur.append(body[i + 1]); i += 2; continue }
                if (c == q) q = null
                i++; continue
            }
            if (c == '"' || c == '\'') { q = c; cur.append(c) }
            else if (c == '(' || c == '[') { d++; cur.append(c) }
            else if (c == ')' || c == ']') { d--; cur.append(c) }
            else if (c == '{' && d == 0) {
                val end = matchBrace(body, i)
                cur.append(body, i, end + 1); i = end + 1
                val rest = body.substring(i).trimStart()
                if (Regex("^(else|catch)\\b").containsMatchIn(rest)) continue
                if (cur.isNotBlank()) res.add(cur.toString())
                cur = StringBuilder(); continue
            } else if (c == ';' && d == 0) { if (cur.isNotBlank()) res.add(cur.toString()); cur = StringBuilder() }
            else cur.append(c)
            i++
        }
        if (cur.isNotBlank()) res.add(cur.toString())
        return res
    }

    private fun headAndBlock(st: String, kw: String): Pair<String, String>? {
        val m = Regex("^$kw\\s*\\(").find(st) ?: return null
        val i = m.range.last; var d = 0
        for (j in i until st.length) {
            if (st[j] == '(') d++ else if (st[j] == ')') { d--; if (d == 0) return st.substring(i + 1, j) to st.substring(j + 1).trim() }
        }
        throw Unconvertible("unbalanced parentheses")
    }

    private fun blockOf(rest0: String): Pair<String, String> {
        val rest = rest0.trim()
        if (rest.startsWith("{")) { val end = matchBrace(rest, 0); return rest.substring(1, end) to rest.substring(end + 1).trim() }
        val parts = splitStatements(rest)
        return (parts.firstOrNull() ?: "") to ""
    }

    private val reLocal = Regex("(?:final|var)\\s+(\\w+)\\s*(?::\\s*[\\w.<>]+)?\\s*(?:=\\s*(.*))?", RegexOption.DOT_MATCHES_ALL)
    private val reCompound = Regex("(.+?)\\s*([+\\-*/])=\\s*(.+)", RegexOption.DOT_MATCHES_ALL)
    private val reIncr = Regex("(\\w[\\w.\\[\\]]*)\\s*(\\+\\+|--)")
    private val reAssign1 = Regex("([^=<>!]+?)\\s=\\s(?!=)(.+)", RegexOption.DOT_MATCHES_ALL)
    private val reAssign2 = Regex("([\\w.\\[\\]()'\"]+)\\s*=(?!=)\\s*(.+)", RegexOption.DOT_MATCHES_ALL)

    private fun convStmt(st: String, ind: Int): List<String> {
        val pad = "\t".repeat(ind)
        if (st.isEmpty()) return emptyList()
        if (Regex("^(switch|try|do)\\b").containsMatchIn(st)) throw Unconvertible("switch / try / do-while")
        headAndBlock(st, "if")?.let { (cond0, rest0) ->
            var cond = cond0; var rest = rest0; val lines = ArrayList<String>(); var first = true
            while (true) {
                val (body, r1) = blockOf(rest); rest = r1
                lines.add("$pad${if (first) "if" else "elseif"} ${convExpr(cond)} then")
                lines += convBlock(body, ind + 1); first = false
                if (rest.startsWith("else")) {
                    rest = rest.substring(4).trim()
                    val r2 = headAndBlock(rest, "if")
                    if (r2 != null) { cond = r2.first; rest = r2.second; continue }
                    val (b2, r3) = blockOf(rest); rest = r3
                    lines.add(pad + "else"); lines += convBlock(b2, ind + 1)
                }
                break
            }
            lines.add(pad + "end"); return lines
        }
        headAndBlock(st, "for")?.let { (head, rest) ->
            val (body, _) = blockOf(rest)
            val lines = ArrayList<String>()
            val m = Regex("\\s*(\\w+)\\s+in\\s+(.+?)\\.\\.\\.(.+)").matchEntire(head)
            if (m != null) lines.add("${pad}for ${m.groupValues[1]} = ${convExpr(m.groupValues[2])}, ${convExpr("(${m.groupValues[3]}) - 1")} do")
            else {
                val m2 = Regex("\\s*(\\w+)\\s+in\\s+(.+)").matchEntire(head) ?: throw Unconvertible("for-loop form")
                lines.add("${pad}for _, ${m2.groupValues[1]} in ipairs(${convExpr(m2.groupValues[2])}) do")
            }
            lines += convBlock(body, ind + 1); lines.add(pad + "end"); return lines
        }
        headAndBlock(st, "while")?.let { (cond, rest) ->
            val (body, _) = blockOf(rest)
            return listOf("${pad}while ${convExpr(cond)} do") + convBlock(body, ind + 1) + listOf(pad + "end")
        }
        if (st.startsWith("{")) { val end = matchBrace(st, 0); return listOf(pad + "do") + convBlock(st.substring(1, end), ind + 1) + listOf(pad + "end") }
        if (st.startsWith("return")) { val v = st.substring(6).trim(); return listOf(pad + if (v.isNotEmpty()) "return " + convExpr(v) else "do return end") }
        if (st == "break" || st == "continue") {
            if (st == "continue") throw Unconvertible("continue (no Lua equivalent without goto)")
            return listOf(pad + "break")
        }
        reLocal.matchEntire(st)?.let { m -> return listOf("${pad}local ${m.groupValues[1]}" + (if (m.groups[2] != null && m.groupValues[2].isNotEmpty()) " = " + convExpr(m.groupValues[2]) else "")) }
        reCompound.matchEntire(st)?.let { m ->
            if (!Regex("[=<>!]=").containsMatchIn(m.groupValues[1])) {
                val t = convExpr(m.groupValues[1])
                val op = if (m.groupValues[2] == "+" && Regex("'|\"").containsMatchIn(m.groupValues[3])) ".." else m.groupValues[2]
                return listOf("$pad$t = $t $op ${convExpr(m.groupValues[3])}")
            }
        }
        reIncr.matchEntire(st)?.let { m -> return listOf("$pad${m.groupValues[1]} = ${m.groupValues[1]} ${m.groupValues[2][0]} 1") }
        (reAssign1.matchEntire(st) ?: reAssign2.matchEntire(st))?.let { m -> return listOf("$pad${convExpr(m.groupValues[1])} = ${convExpr(m.groupValues[2])}") }
        return listOf(pad + convExpr(st))
    }

    /** guards odd output: every opener has its end, brackets match */
    private fun luaBalanced(code0: String): Boolean {
        val code = Regex("'(?:\\\\.|[^'\\\\])*'|\"(?:\\\\.|[^\"\\\\])*\"|--[^\\n]*").replace(code0, "")
        val opens = Regex("\\b(function|if|for|while|do)\\b").findAll(code).count() -
            Regex("\\bfor\\b[^\\n]*\\bdo\\b|\\bwhile\\b[^\\n]*\\bdo\\b").findAll(code).count()
        return opens == Regex("\\bend\\b").findAll(code).count() && code.count { it == '(' } == code.count { it == ')' } && code.count { it == '{' } == code.count { it == '}' }
    }

    // ------------------------------------------------------------------ file level
    fun convertSource(src: String, kind: String, name: String): Pair<String, Result> {
        val r = Result(); val lines = ArrayList<String>(); lines.add("-- PortYou Studio: converted from $name ($kind)")
        val members = splitMembers(src)
        if (members.isEmpty()) r.failed.add(Failure(name, "<file>", "no functions or variables recognised", src.trim().take(4000)))
        for (mem in members) {
            when (mem) {
                is Member.Var -> try {
                    lines += convStmt(mem.text.trim().trimEnd(';').replace("public ", "").replace("static ", "").replace("private ", ""), 0)
                } catch (ex: Unconvertible) { r.failed.add(Failure(name, "<variable>", ex.message ?: "", mem.text)) }
                is Member.Fn -> {
                    if (mem.name == "new" || mem.name == "getEventSchema" || mem.name == "getTitle") continue   // editor-only metadata, Psych has no use for it
                    val lname = callbacks[mem.name] ?: mem.name
                    val params = mem.args.split(',').map { it.replace(Regex("\\s*[:=].*$"), "").trim() }.filter { it.isNotEmpty() }
                    try {
                        val code = convBlock(mem.body)
                        // every converted callback runs inside pcall: a missing API can never pop up "Error on lua script!" in game
                        val lua = (listOf("function $lname(${params.joinToString(", ")})", "\tlocal __ok, __r = pcall(function()") + code.map { "\t" + it } +
                            listOf("\tend)", "\tif __ok then return __r end", "end")).joinToString("\n")
                        if (!luaBalanced(lua)) throw Unconvertible("result did not pass the syntax balance check")
                        lines.add(lua); r.ok++
                    } catch (ex: Unconvertible) {
                        r.failed.add(Failure(name, mem.name, ex.message ?: "", "function ${mem.name}(${mem.args}) {${mem.body}}"))
                        lines.add("-- PortYou: function \"${mem.name}\" was NOT converted (${ex.message})")
                    } catch (ex: StackOverflowError) {
                        r.failed.add(Failure(name, mem.name, "too deeply nested", "function ${mem.name}(${mem.args}) {${mem.body}}"))
                    }
                }
            }
        }
        return lines.joinToString("\n") + "\n" to r
    }

    /** V-Slice SongEvent.handleEvent(data) -> Psych custom event onEvent(name, v1, v2); data.value = parsed 'k=v;k=v' */
    private fun eventWrapper(kind: String, lua0: String): String {
        val lua = lua0.replace(Regex("\\bfunction handleEvent\\("), "local function handleEvent(")
        val pre = "local function _parse(s) local t = {} for kv in string.gmatch(s or \"\", \"[^;]+\") do local k, v = string.match(kv, \"^([^=]+)=(.*)\$\") " +
            "if k then t[k] = tonumber(v) or (v == \"true\" and true) or (v == \"false\" and false) or v end end return t end\n"
        val q = "'" + kind.replace("\\", "\\\\").replace("'", "\\'") + "'"
        return pre + lua + "\nfunction onEvent(name, v1, v2)\n\tif name == $q then pcall(handleEvent, {value = _parse(v1), event = name}) end\nend\n"
    }

    /** Convert a source file as Lua when every executable member is understood. If not,
     * keep the complete script as Psych HScript instead of shipping a partial/no-op Lua file. */
    private fun hscriptArgs(args0: String): String {
        return Regex(":\\s*(?:Null<[^>]+>|Array<[^>]+>|[A-Za-z_][A-Za-z0-9_.]*(?:<[^>]+>)?)")
            .replace(args0, "").trim()
    }

    private fun hscriptBody(body0: String): String {
        var body = body0
        // HScript scripts are top-level scripts, not V-Slice SongEvent classes.
        body = Regex("(?m)^\\s*super\\.[A-Za-z_]\\w*\\([^;\\n]*\\);?\\s*").replace(body, "")
        body = Regex("\\bsuper\\.[A-Za-z_]\\w*\\([^;]*\\);?").replace(body, "")
        // Convert Codename/V-Slice's video helper to the public Psych PlayState API.
        val video = Regex("VideoCutscene\\.play\\(\\s*Paths\\.videos\\(\\s*['\"]([^'\"]+)['\"]\\s*\\)\\s*\\)")
        body = video.replace(body) { "PlayState.instance.startVideo(\"${it.groupValues[1]}\")" }
        // Common Codename/V-Slice APIs that have direct Psych Engine equivalents.
        body = body.replace("PlayState.instance.currentStage.getGirlfriend()", "PlayState.instance.gf")
            .replace("PlayState.instance.currentStage", "PlayState.curStage")
            .replace("PlayState.instance.isMinimalMode", "false")
            .replace("PlayState.instance.currentSong.id", "PlayState.SONG.song")
            .replace("PlayState.instance.camGame.canvas", "PlayState.instance.camGame")
            .replace("PlayState.instance.camHUD.canvas", "PlayState.instance.camHUD")
            .replace(".cameraFocusPoint", ".getMidpoint()")
            .replace(".playAnimation(", ".playAnim(")
            .replace(".isAnimationFinished()", ".animation.curAnim.finished")
            .replace("ReflectUtil.getClassNameOf(FlxG.state)", "Type.getClassName(Type.getClass(FlxG.state))")
            .replace("PlayState.instance.currentCameraZoom", "PlayState.instance.camGame.zoom")
            .replace(".rotation", ".angle")
            .replace("\"rotation\"", "\"angle\"")
            .replace("FlxTween.tween(PlayState.instance,", "FlxTween.tween(PlayState.instance.camGame,")
            .replace("{ currentCameraZoom:", "{ zoom:")
            .replace("PlayState.instance.cancelCameraFollowTween();", "")
            .replace("PlayState.instance.resetCamera(false, false, false);", "")
            .replace("PlayState.instance.cameraFollowPoint", "PlayState.instance.camFollow")
        // V-Slice event classes expose inherited character aliases; Psych HScript scripts
        // need explicit references to the active PlayState characters instead.
        body = Regex("\\b(gf|boyfriend|dad)\\.").replace(body) { "PlayState.instance.${it.groupValues[1]}." }
        body = Regex("PlayState\\.instance\\.tweenCameraToPosition\\(([^,]+),\\s*([^,]+),\\s*[^)]+\\)").replace(body) {
            "PlayState.instance.camFollow.setPosition(${it.groupValues[1]}, ${it.groupValues[2]})"
        }
        // The old cutscene helper's temporary black sprite is not needed in Psych: startVideo
        // owns its cutscene camera and completion callback. Preserve the original random/once gate.
        if (body.contains("FunkinSprite") && body.contains("startVideo")) {
            // Strip only the temporary V-Slice blackout sprite. Do not consume the video call:
            // Psych's startVideo owns the cutscene camera and its resume callback.
            body = Regex("(?m)^\\s*bgSprite\\s*=\\s*new\\s+FunkinSprite\\([^;]*;\\s*").replace(body, "")
            body = Regex("(?m)^\\s*bgSprite\\.makeSolidColor\\([^;]*;\\s*").replace(body, "")
            body = Regex("(?m)^\\s*bgSprite\\.(?:cameras|zIndex|visible)\\s*=\\s*[^;]*;\\s*").replace(body, "")
            body = Regex("(?m)^\\s*PlayState\\.instance\\.(?:add|refresh)\\([^;]*;\\s*").replace(body, "")
            body = Regex("(?s)FlxTween\\.tween\\(bgSprite,.*?\\);\\s*").replace(body, "")
            body = body.replace("event.cancel();", "return Function_Stop;")
            body = body.replace("event.cancel()", "return Function_Stop")
        }
        body = Regex("\\bfinal\\s+").replace(body, "var ")
        body = Regex("\\b(var|final)\\s+(\\w+)\\s*:\\s*[A-Za-z_][A-Za-z0-9_.<>?]*").replace(body) { "${it.groupValues[1]} ${it.groupValues[2]}" }
        // HScript-iris uses Haxe expressions, but the null-safe/coalescing syntax in newer V-Slice
        // builds is not supported by all Psych 1.0.4 mobile builds.
        body = Regex("([A-Za-z_][A-Za-z0-9_.]*)\\?\\.([A-Za-z_][A-Za-z0-9_]*)").replace(body) { "(${it.groupValues[1]} != null ? ${it.groupValues[1]}.${it.groupValues[2]} : null)" }
        body = Regex("(\\([^()]*\\)|[A-Za-z_][A-Za-z0-9_.]*)\\s*\\?\\?\\s*(\"[^\"]*\"|'[^']*'|[A-Za-z_][A-Za-z0-9_.]*|[0-9]+)")
            .replace(body) { "(${it.groupValues[1]} != null ? ${it.groupValues[1]} : ${it.groupValues[2]})" }
        // Convert the common single-expression Haxe lambda used by FlxTween callbacks.
        body = Regex("\\(([^()]*?)\\)\\s*->\\s*([^,}\\n]+)").replace(body) { "function(${it.groupValues[1]}) { ${it.groupValues[2].trim()}; }" }
        return body
    }

    private fun hscriptFallback(src: String, kind: String, eventName: String?, fileName: String): String? {
        val members = try { splitMembers(src) } catch (_: Exception) { return null }
        if (members.none { it is Member.Fn }) return null
        val base = eventName ?: fileName.substringBeforeLast('.')
        val out = StringBuilder("// PortYou Studio: preserved Haxe logic as Psych Engine HScript\n")
        // Keep the imports used by fallback members; splitMembers intentionally strips the class shell.
        Regex("(?m)^\\s*(?:import|using)\\s+[^;]+;").findAll(src).forEach { out.append(it.value.trim()).append("\n") }
        val wrappers = ArrayList<String>()
        val hasCtor = members.any { it is Member.Fn && it.name == "new" }
        var hasCreate = false
        var hasHandleEvent = false
        var hasSongEvent = false
        var hasOnEvent = false
        for (member in members) when (member) {
            is Member.Var -> {
                var v = member.text.trim().trimEnd(';')
                v = Regex("\\b(public|private|static|inline|final)\\s+").replace(v, "")
                v = Regex("(:\\s*(?:Null<[^>]+>|Array<[^>]+>|[A-Za-z_][A-Za-z0-9_.]*(?:<[^>]+>)?))").replace(v, "")
                if (v.isNotBlank()) out.append(v).append(";\n")
            }
            is Member.Fn -> {
                if (member.name == "getEventSchema" || member.name == "getTitle") continue
                val args = hscriptArgs(member.args)
                var body = hscriptBody(member.body)
                val params = args.split(',').map { it.trim().substringBefore('=').trim() }.filter { it.isNotEmpty() }
                when (member.name) {
                    "new" -> out.append("function __portyou_init() {\n").append(body).append("\n}\n")
                    "handleEvent" -> { hasHandleEvent = true; out.append("function handleEvent($args) {\n").append(body).append("\n}\n") }
                    "onSongEvent" -> { hasSongEvent = true; out.append("function __portyou_onSongEvent($args) {\n").append(body).append("\n}\n") }
                    "onEvent" -> { hasOnEvent = true; out.append("function __portyou_onEvent($args) {\n").append(body).append("\n}\n") }
                    "onCountdownStart" -> {
                        // Psych's onStartCountdown must return Function_Stop after launching a cutscene,
                        // otherwise the countdown starts behind the video in Story and Freeplay.
                        body = Regex("\\bevent\\.cancel\\(\\)\\s*;?").replace(body, "return Function_Stop;")
                        out.append("function onStartCountdown() {\n").append(body).append("\n}\n")
                    }
                    "onBeatHit" -> if (params.isNotEmpty()) {
                        out.append("function __portyou_onBeatHit($args) {\n").append(body).append("\n}\n")
                        wrappers.add("function onBeatHit(curBeat) { __portyou_onBeatHit({beat: curBeat}); }\n")
                    } else out.append("function onBeatHit() {\n").append(body).append("\n}\n")
                    "onUpdate" -> if (params.isNotEmpty()) {
                        out.append("function __portyou_onUpdate($args) {\n").append(body).append("\n}\n")
                        wrappers.add("function onUpdate(elapsed) { __portyou_onUpdate({elapsed: elapsed}); }\n")
                    } else out.append("function onUpdate() {\n").append(body).append("\n}\n")
                    "onCreate" -> {
                        hasCreate = true
                        out.append("function __portyou_onCreate() {\n").append(body).append("\n}\n")
                    }
                    "create" -> {
                        hasCreate = true
                        out.append("function __portyou_create() {\n").append(body).append("\n}\n")
                    }
                    "onCreatePost", "postCreate" -> out.append("function onCreatePost() {\n").append(body).append("\n}\n")
                    "onStepHit", "stepHit" -> out.append("function onStepHit() {\n").append(body).append("\n}\n")
                    "onSectionHit" -> out.append("function onSectionHit() {\n").append(body).append("\n}\n")
                    "onSongStart" -> out.append("function onSongStart() {\n").append(body).append("\n}\n")
                    "onCountdownStarted" -> out.append("function onCountdownStarted() {\n").append(body).append("\n}\n")
                    else -> out.append("function ${member.name}($args) {\n").append(body).append("\n}\n")
                }
            }
        }
        if (kind == "event" || hasHandleEvent || hasSongEvent || hasOnEvent) {
            val q = "\"" + base.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
            out.append("\nfunction __portyou_eventValues(v1, v2) {\n")
            out.append("  var values = {value1: v1, value2: v2};\n")
            out.append("  if (v1 != null) for (part in Std.string(v1).split(\";\")) { var at = part.indexOf(\"=\"); if (at > 0) Reflect.setField(values, part.substr(0, at), part.substr(at + 1)); }\n")
            out.append("  return values;\n}\n")
            out.append("function onEvent(name, value1, value2) {\n")
            if (hasHandleEvent) out.append("  if (name == $q) handleEvent({value: __portyou_eventValues(value1, value2), event: name});\n")
            if (hasSongEvent) {
                out.append("  var values = __portyou_eventValues(value1, value2);\n")
                out.append("  var eventData = {eventKind: name, " +
                    "getInt: function(key) { return Std.parseInt(Reflect.field(values, key)); }, " +
                    "getFloat: function(key) { return Std.parseFloat(Reflect.field(values, key)); }, " +
                    "getString: function(key) { var v = Reflect.field(values, key); return v == null ? null : Std.string(v); }, " +
                    "getBool: function(key) { var v = Std.string(Reflect.field(values, key)).toLowerCase(); return v == 'true' || v == '1'; }};\n")
                out.append("  __portyou_onSongEvent({eventData: eventData});\n")
            }
            if (hasOnEvent) out.append("  __portyou_onEvent(name, value1, value2);\n")
            out.append("}\n")
        }
        if (hasCtor || hasCreate) {
            val calls = ArrayList<String>()
            if (hasCtor) calls.add("if (__portyou_init != null) __portyou_init();")
            if (members.any { it is Member.Fn && it.name == "onCreate" }) calls.add("if (__portyou_onCreate != null) __portyou_onCreate();")
            if (members.any { it is Member.Fn && it.name == "create" }) calls.add("if (__portyou_create != null) __portyou_create();")
            wrappers.add("function onCreate() { ${calls.joinToString(" ")} }\n")
        }
        wrappers.forEach { out.append(it) }
        return out.toString()
    }

    /** Writes converted scripts into the mod. Unsupported methods fall back to HScript (.hx),
     * which Psych 1.0.4 loads when HSCRIPT_ALLOWED is enabled. The original snippets are also
     * recorded in the diagnostic folder so a user can inspect every fallback. */
    fun convertMany(files: List<HxFile>, outDir: File, unconvertedDir: File): Pair<Int, List<Failure>> {
        val failures = ArrayList<Failure>(); var okFiles = 0
        for (f in files) {
            val base = f.path.nameWithoutExtension
            val src = try { f.path.readText() } catch (ex: Exception) { failures.add(Failure(f.path.name, "<file>", ex.message ?: "", "")); continue }
            val res: Pair<String, Result> = try { convertSource(src, f.kind, f.path.name) }
                catch (ex: Exception) { failures.add(Failure(f.path.name, "<file>", ex.message ?: "", "")); continue }
            var lua = res.first; val r = res.second
            val useHScript = r.failed.isNotEmpty()
            if (useHScript) {
                val hs = hscriptFallback(src, f.kind, f.event, f.path.name)
                if (hs != null) {
                    val dest = when (f.kind) {
                        "event" -> File(outDir, "custom_events/${f.event ?: base}.hx")
                        // Psych 1.0.4's stage Lua loader does not load stages/*.hx; generic
                        // HScript files under scripts/ are discovered by the HScript manager.
                        "stage" -> File(outDir, "scripts/hx_stage_$base.hx")
                        else -> File(outDir, "scripts/hx_$base.hx")
                    }
                    dest.parentFile?.mkdirs(); dest.writeText(hs); okFiles++
                }
            } else if (r.ok > 0) {
                val dest: File = when (f.kind) {
                    "event" -> { lua = eventWrapper(f.event ?: base, lua); File(outDir, "custom_events/${f.event ?: base}.lua") }
                    "stage" -> File(outDir, "stages/$base.lua").also { if (it.isFile) lua = it.readText() + "\n" + lua }
                    else -> File(outDir, "scripts/hx_$base.lua")
                }
                dest.parentFile?.mkdirs(); dest.writeText(lua); okFiles++
            }
            failures += r.failed
        }
        if (failures.isNotEmpty()) writeUnconverted(failures, unconvertedDir)
        return okFiles to failures
    }

    private val head = mapOf(
        "ar" to "تعذّر تحويل بعض دوال Haxe إلى Lua. احتفظ PortYou بالملف كـ HScript عندما أمكن، وهذه قائمة الأجزاء التي تحتاج مراجعة:",
        "en" to "Some Haxe functions could not be converted to Lua. PortYou kept the file as HScript when possible; review the remaining items below:",
        "pt" to "Algumas funções Haxe não puderam ser convertidas para Lua. O PortYou manteve o arquivo como HScript quando possível; revise os itens abaixo:",
        "ja" to "一部のHaxe関数をLuaに変換できませんでした。可能な場合はHScriptとして保持しました。以下を確認してください:")

    private fun writeUnconverted(failures: List<Failure>, d: File) {
        d.mkdirs()
        val txt = ArrayList<String>()
        for ((l, h) in head) txt.add("=".repeat(60) + "\n[$l] $h\n")
        txt.add("=".repeat(60))
        for (f in failures) txt.add("\n* ${f.file} :: ${f.fn}\n    reason: ${f.why}")
        File(d, "ماقدرت_احول_ذا_COULD_NOT_CONVERT.txt").writeText(txt.joinToString("\n") + "\n")
        val raw = File(d, "haxe_sources").also { it.mkdirs() }
        for (f in failures) if (f.code.isNotEmpty()) File(raw, "${f.file.substringBeforeLast('.')}__${f.fn.replace(Regex("\\W"), "_")}.hx").writeText(f.code)
    }
}
