-- PortYou Studio: FNMM runtime (generated). Executes every Funky Maker action inside Psych Engine.
local CAMS = { --[[CAMS]] }
--[[CHAROBJ]]
--[[CHAR_SCALES]]
local OBJS = {
--[[OBJS]]
}
local SPRS = {
--[[SPRS]]
}
local EASE = {default='sineInOut', linear='linear', cubic='cubeInOut', expo='expoInOut', back='backInOut',
	elastic='elasticInOut', bounce='bounceInOut', circ='circInOut', slow='sineInOut'}
local chartObj = {}   -- strumLine -> object index taking over its notes
local cur = {}        -- idx -> {sprite=name, anim=k, o=object data}
local charOverlays = {} -- character object index -> active replacement sprite
local flashN = 0

local function P(v1)
	local t = {}
	for kv in string.gmatch(v1 or '', '[^;]+') do
		local k, v = string.match(kv, '^([^=]+)=(.*)$')
		if k then t[k] = v end
	end
	return t
end
local function secs(t, key, unitKey)
	local d = tonumber(t[key]) or 0
	if (t[unitKey] or 'seconds') == 'beats' then d = d * (crochet / 1000) end
	return d
end
local function objChar(idx)
	if idx == CHAR_OBJ[0] then return 'boyfriend' end
	if idx == CHAR_OBJ[1] then return 'dad' end
	return nil
end
local function tagOf(idx) return 'fnmm' .. idx end
local ZOOM_K = 0.7   -- stage defaultZoom = FNMM camera scale * 0.7 (see stage json), so every zoom value uses the same factor
local FRONT_FROM = math.huge
for _, ci in pairs(CHAR_OBJ) do if ci >= 0 and ci < FRONT_FROM then FRONT_FROM = ci end end
local function clampZoom(z) if z < 0.05 then return 0.05 end return z end
local function clamp01(v) if v < 0 then return 0 end if v > 1 then return 1 end return v end

local function setupAnim(tag, a, idx)
	loadGraphic(tag, a.img, a.fw, a.fh)
	if a.frames > 1 then
		local fr = {}
		for i = 0, a.frames - 1 do fr[#fr + 1] = i end
		addAnimation(tag, 'a', fr, math.floor(a.fps + 0.5), a.loop)
		objectPlayAnimation(tag, 'a', true)
	end
end

local function place(tag, o, a)
	local sx = (tonumber(o.scaleX or o.scale) or 1) * (tonumber(a.sx) or 1)
	local sy = (tonumber(o.scaleY or o.scale) or 1) * (tonumber(a.sy) or 1)
	local cx, cy = tonumber(o.cx) or 0, tonumber(o.cy) or 0
	if o.fixed then
		-- Funky Maker stores fixed overlay positions as normalized screen coordinates.
		if math.abs(cx) <= 1 then cx = cx * screenWidth end
		if math.abs(cy) <= 1 then cy = cy * screenHeight end
	end
	scaleObject(tag, sx, sy, true)
	setProperty(tag .. '.x', cx - (tonumber(a.ox) or (a.fw / 2)) * sx)
	setProperty(tag .. '.y', cy - (tonumber(a.oy) or (a.fh / 2)) * sy)
	setProperty(tag .. '.scrollFactor.x', o.fixed and 0 or (tonumber(o.scrollX) or 1))
	setProperty(tag .. '.scrollFactor.y', o.fixed and 0 or (tonumber(o.scrollY) or 1))
end

local function setCharAnimScale(idx, animIndex)
	local c = objChar(idx)
	local rows = CHAR_ANIM_SCALES[idx]
	local scale = rows and rows[animIndex]
	if c and scale then
		setProperty(c .. '.scale.x', scale[1])
		setProperty(c .. '.scale.y', scale[2])
	end
end

local function characterAnimIndex(c)
	local anim = tostring(getProperty(c .. '.animation.curAnim.name') or '')
	local lower = string.lower(anim)
	if string.find(lower, 'miss', 1, true) or string.find(lower, 'hurt', 1, true) or string.find(lower, 'dodge', 1, true) then return 6 end
	if string.find(lower, 'shoot', 1, true) or string.find(lower, 'special', 1, true) or string.find(lower, 'hey', 1, true) then return 7 end
	if string.find(lower, 'singleft', 1, true) then return 2 end
	if string.find(lower, 'singdown', 1, true) then return 3 end
	if string.find(lower, 'singup', 1, true) then return 4 end
	if string.find(lower, 'singright', 1, true) then return 5 end
	return 1
end

local function setCharacterOverlayAnimation(idx, animIndex)
	local state = charOverlays[idx]
	if not state then return end
	local c = objChar(idx)
	local defs = SPRS[state.sprite]
	local a = defs and (defs[animIndex] or defs[1])
	if not a then return end
	state.anim = animIndex
	setupAnim(state.tag, a, idx)
	if c then
		place(state.tag, {
			cx = getMidpointX(c), cy = getMidpointY(c),
			scaleX = tonumber(getProperty(c .. '.scale.x')) or 1,
			scaleY = tonumber(getProperty(c .. '.scale.y')) or 1,
			scrollX = tonumber(getProperty(c .. '.scrollFactor.x')) or 1,
			scrollY = tonumber(getProperty(c .. '.scrollFactor.y')) or 1
		}, a)
	end
end

local function syncCharacterOverlay(idx, state)
	local c = objChar(idx)
	if not c or not state or not luaSpriteExists(state.tag) then return end
	local detected = characterAnimIndex(c)
	if detected ~= (state.anim or 1) then
		state.anim = detected
		local nextDefs = SPRS[state.sprite]
		local nextAnim = nextDefs and (nextDefs[detected] or nextDefs[1])
		if nextAnim then setupAnim(state.tag, nextAnim, idx) end
	end
	local defs = SPRS[state.sprite]
	local a = defs and (defs[state.anim or 1] or defs[1])
	if not a then return end
	place(state.tag, {
		cx = getMidpointX(c), cy = getMidpointY(c),
		scaleX = tonumber(getProperty(c .. '.scale.x')) or 1,
		scaleY = tonumber(getProperty(c .. '.scale.y')) or 1,
		scrollX = tonumber(getProperty(c .. '.scrollFactor.x')) or 1,
		scrollY = tonumber(getProperty(c .. '.scrollFactor.y')) or 1
	}, a)
	-- Keep all visual modifiers attached to the replacement sprite. The character remains
	-- the transform/animation anchor, so tinting never changes its dimensions or position.
	setProperty(state.tag .. '.alpha', tonumber(getProperty(c .. '.alpha')) or 1)
	setProperty(state.tag .. '.color', getProperty(c .. '.color'))
	setProperty(state.tag .. '.angle', tonumber(getProperty(c .. '.angle')) or 0)
	setProperty(state.tag .. '.flipX', getProperty(c .. '.flipX') == true)
	setProperty(state.tag .. '.flipY', getProperty(c .. '.flipY') == true)
	setProperty(state.tag .. '.visible', state.visible ~= false)
end

function onUpdatePost(elapsed)
	-- Match the exact X/Y scale authored for the active animation, including ordinary
	-- note-hit animations that are played by Psych itself (not only custom FNMM events).
	for _, idx in ipairs({CHAR_OBJ[0], CHAR_OBJ[1]}) do
		if idx ~= nil and idx >= 0 then
			local c = objChar(idx)
			if c then setCharAnimScale(idx, characterAnimIndex(c)) end
		end
	end
	for idx, state in pairs(charOverlays) do syncCharacterOverlay(idx, state) end
end

function onCreate()
	for _, o in ipairs(OBJS) do
		local tag = tagOf(o.idx)
		local a = o.anims[1]
		makeLuaSprite(tag, a.img, 0, 0)
		setupAnim(tag, a, o.idx)
		place(tag, o, a)
		setProperty(tag .. '.visible', o.visible)
		setProperty(tag .. '.alpha', tonumber(o.alpha) or 1)
		if o.color then setProperty(tag .. '.color', getColorFromHex(o.color)) end
		if o.fixed then setObjectCamera(tag, 'camOther') end
		addLuaSprite(tag, o.idx > FRONT_FROM)
		cur[o.idx] = {sprite = o.spr, anim = 1, o = o}
	end
end

function onCreatePost()
	if CHAR_OBJ[1] == -1 then setProperty('dad.visible', false) end
	-- Restore the actual X/Y scale from Funky Maker (Psych character JSON only stores one scale).
	if CHAR_OBJ[0] and CHAR_OBJ[0] >= 0 then setCharAnimScale(CHAR_OBJ[0], 1) end
	if CHAR_OBJ[1] and CHAR_OBJ[1] >= 0 then setCharAnimScale(CHAR_OBJ[1], 1) end
	local c1 = CAMS[1]
	if c1 then
		setProperty('isCameraOnForcedPos', true)
		setProperty('camFollow.x', c1[1]); setProperty('camFollow.y', c1[2])
		setProperty('camGame.scroll.x', c1[1] - screenWidth / 2); setProperty('camGame.scroll.y', c1[2] - screenHeight / 2)
		local z = clampZoom((c1[3] or 1) * ZOOM_K)
		setProperty('defaultCamZoom', z); setProperty('camGame.zoom', z)
	end
	setProperty('camGame.alpha', 1); setProperty('camHUD.alpha', 1)
end

local function overlayFor(idx, sprName)
	-- Replaces only the character's rendered sprite. Position, scale, flip, alpha and tint
	-- continue to come from the real Psych character so the object stays pixel-aligned.
	local s = SPRS[sprName]
	if not s then return nil end
	local tag = 'fnmmov' .. idx .. sprName
	if not luaSpriteExists(tag) then
		local a = s[1]
		makeLuaSprite(tag, a.img, 0, 0)
		setupAnim(tag, a, idx)
		addLuaSprite(tag, true)
		local c = objChar(idx)
		if c then setObjectOrder(tag, getObjectOrder(c)) end
		setProperty(tag .. '.visible', false)
	end
	return tag
end

local function handle(name, v1, v2)
	local t = P(v1)
	if name == 'ScreenFlash' then
		flashN = flashN + 1
		local tag = 'fnmmFlash' .. flashN
		local r, g, b = tonumber(t.color_r) or 255, tonumber(t.color_g) or 255, tonumber(t.color_b) or 255
		makeLuaSprite(tag, nil, 0, 0)
		makeGraphic(tag, screenWidth, screenHeight, string.format('%02X%02X%02X', r, g, b))
		setObjectCamera(tag, 'camOther')
		setProperty(tag .. '.alpha', clamp01(tonumber(t.alpha) or 1))
		addLuaSprite(tag, true)
		doTweenAlpha('fnmmFlashT' .. flashN, tag, 0, secs(t, 'duration', 'timeUnit'), 'linear')
	elseif name == 'CameraShake' then
		cameraShake('camGame', (tonumber(t.strength) or 5) * 0.00005, secs(t, 'delay', 'timeUnit') * (tonumber(t.shakes) or 1))
	elseif name == 'CameraSet' then
		if t.mode == 'auto' then
			setProperty('isCameraOnForcedPos', false)
			triggerEvent('Camera Follow Pos', '', '')
		else
			local c = CAMS[(tonumber(t.target) or 0) + 1] or CAMS[1]
			setProperty('isCameraOnForcedPos', true)
			local d = secs(t, 'transitionTime', 'transitionTimeUnit')
			local e = EASE[t.easingType or 'default'] or 'sineInOut'
			if c[3] then setProperty('defaultCamZoom', clampZoom(c[3] * ZOOM_K)) end
			if d <= 0 then
				setProperty('camFollow.x', c[1]); setProperty('camFollow.y', c[2])
			else
				doTweenX('fnmmCamX', 'camFollow', c[1], d, e)
				doTweenY('fnmmCamY', 'camFollow', c[2], d, e)
			end
		end
	elseif name == 'CameraZoom' then
		local d = secs(t, 'transitionTime', 'transitionTimeUnit')
		local z = clampZoom((tonumber(t.value) or 1) * ZOOM_K)
		if d <= 0 then setProperty('camGame.zoom', z); setProperty('defaultCamZoom', z)
		else
			setProperty('defaultCamZoom', z)
			doTweenZoom('fnmmZoom', 'camGame', z, d, EASE[t.easingType or 'default'] or 'sineInOut')
		end
	elseif name == 'GUI' then
		setProperty('camHUD.visible', t.visible ~= '0')
	elseif name == 'BarIconChange' then
		local ic = (t.target == '1') and 'iconP1' or 'iconP2'
		callMethod(ic .. '.changeIcon', {'fnmm-' .. (t.sprite or '')})
	elseif name == 'PlayerHealth' then
		local h, v, mn = getProperty('health'), (tonumber(t.value) or 0) / 50, (tonumber(t.minHealth) or 0) / 50
		if t.operation == 'add' then h = h + v elseif t.operation == 'remove' then h = h - v else h = v end
		if h < mn then h = mn end
		setProperty('health', h)
	elseif name == 'ObjectVisibilitySet' then
		local idx = tonumber(t.object)
		local vis = t.value == '1'
		local c = objChar(idx)
		if c then
			local state = charOverlays[idx]
			if state then state.visible = vis; setProperty(c .. '.visible', false); setProperty(state.tag .. '.visible', vis)
			else setProperty(c .. '.visible', vis) end
		else setProperty(tagOf(idx) .. '.visible', vis) end
	elseif name == 'ObjectOpacitySet' then
		local idx = tonumber(t.object)
		local tag = objChar(idx) or tagOf(idx)
		local d = secs(t, 'transitionTime', 'transitionTimeUnit')
		local v = tonumber(t.value) or 1
		if d <= 0 then setProperty(tag .. '.alpha', v) else doTweenAlpha('fnmmOp' .. idx, tag, v, d, 'linear') end
		local state = charOverlays[idx]
		if state then setProperty(state.tag .. '.alpha', v) end
	elseif name == 'ObjectBlendColor' then
		local idx = tonumber(t.object)
		local tag = objChar(idx) or tagOf(idx)
		local hex = string.format('%02X%02X%02X', tonumber(t.color_r) or 255, tonumber(t.color_g) or 255, tonumber(t.color_b) or 255)
		local color = getColorFromHex(hex)
		setProperty(tag .. '.color', color)
		local state = charOverlays[idx]
		if state then setProperty(state.tag .. '.color', color) end
	elseif name == 'ObjectPositionSet' then
		local idx = tonumber(t.object)
		local o = cur[idx] and cur[idx].o
		local tag = objChar(idx) or tagOf(idx)
		local x, y = tonumber(t['transform.x']), tonumber(t['transform.y'])
		if x and y then
			local activeIndex = cur[idx] and cur[idx].anim or 1
			local a = o and (o.anims[activeIndex] or o.anims[1])
			local sx = o and ((o.scaleX or o.scale or 1) * ((a and a.sx) or 1)) or 1
			local sy = o and ((o.scaleY or o.scale or 1) * ((a and a.sy) or 1)) or 1
			if o and o.fixed then
				if math.abs(x) <= 1 then x = x * screenWidth end
				if math.abs(y) <= 1 then y = y * screenHeight end
			end
			local nx = a and (x - (a.ox or a.fw / 2) * sx) or x
			local ny = a and (y - (a.oy or a.fh / 2) * sy) or y
			local d = secs(t, 'transitionTime', 'transitionTimeUnit')
			if d <= 0 then setProperty(tag .. '.x', nx); setProperty(tag .. '.y', ny)
			else
				local e = EASE[t.easingType or 'default'] or 'sineInOut'
				doTweenX('fnmmPX' .. idx, tag, nx, d, e); doTweenY('fnmmPY' .. idx, tag, ny, d, e)
			end
		end
	elseif name == 'ObjectSpriteSet' then
		local idx = tonumber(t.object)
		local c = objChar(idx)
		if c then
			local spriteName = t.sprite or ''
			local tag = overlayFor(idx, spriteName)
			if tag then
				local old = charOverlays[idx]
				if old and old.tag ~= tag then setProperty(old.tag .. '.visible', false) end
				local wasVisible = true
				if old then wasVisible = old.visible ~= false else wasVisible = getProperty(c .. '.visible') ~= false end
				charOverlays[idx] = {tag = tag, sprite = spriteName, anim = 1, visible = wasVisible}
				setProperty(c .. '.visible', false)
				syncCharacterOverlay(idx, charOverlays[idx])
			end
		elseif SPRS[t.sprite] then
			local a = SPRS[t.sprite][1]
			local o = cur[idx] and cur[idx].o
			setupAnim(tagOf(idx), a, idx)
			if o then place(tagOf(idx), o, a) end
			cur[idx].sprite = t.sprite; cur[idx].anim = 1
		end
	elseif name == 'ObjectAnimationSet' then
		local idx = tonumber(t.object)
		local k = (tonumber(t.anim) or 0) + 1
		local c = objChar(idx)
		if c then
			local names = {'idle', 'singLEFT', 'singDOWN', 'singUP', 'singRIGHT', 'miss', 'special'}
			if names[k] then
				setProperty(c .. '.skipDance', k > 1)
				characterPlayAnim(c, names[k], true)
				setCharAnimScale(idx, k)
				if charOverlays[idx] then
					setCharacterOverlayAnimation(idx, k)
					syncCharacterOverlay(idx, charOverlays[idx])
				end
			end
		else
			local s = cur[idx] and SPRS[cur[idx].sprite]
			if s and s[k] then
				setupAnim(tagOf(idx), s[k], idx)
				if cur[idx].o then place(tagOf(idx), cur[idx].o, s[k]) end
				cur[idx].anim = k
			end
		end
	elseif name == 'ObjectChartChange' then
		local sl = tonumber(t.strumLine) or -1
		chartObj[sl] = (sl >= 0) and (tonumber(t.object) or nil) or nil
	end
end

function onEvent(name, v1, v2)
	local ok, err = pcall(handle, name, v1, v2)
	if not ok then debugPrint('PortYou FNMM event ' .. tostring(name) .. ': ' .. tostring(err)) end
end

local DIRN = {[0] = 2, [1] = 3, [2] = 4, [3] = 5}  -- note column -> animation index+1 (left, down, up, right)
local function hit(player, dir)
	local sl = player and 0 or 1
	local idx = chartObj[sl]
	local k = DIRN[dir]
	if idx and objChar(idx) then
		setCharAnimScale(idx, k)
		if charOverlays[idx] then
			setCharacterOverlayAnimation(idx, k)
			syncCharacterOverlay(idx, charOverlays[idx])
		end
	elseif idx then
		local s = cur[idx] and SPRS[cur[idx].sprite]
		if s and s[k] then
			setupAnim(tagOf(idx), s[k], idx)
			if cur[idx].o then place(tagOf(idx), cur[idx].o, s[k]) end
		end
	end
end
function goodNoteHit(id, dir, nt, sus) hit(true, dir) end
function opponentNoteHit(id, dir, nt, sus) hit(false, dir) end

function onTweenCompleted(tag)
	if string.sub(tag, 1, 11) == 'fnmmFlashT' then removeLuaSprite('fnmmFlash' .. string.sub(tag, 12), true) end
end
