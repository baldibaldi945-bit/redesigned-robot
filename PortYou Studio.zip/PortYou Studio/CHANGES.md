# PortYou Studio — build 1.8 (conversion accuracy patch)

## What changed

- **Funky Maker output is rebuilt cleanly each conversion.** Old files from earlier runs can no longer remain in the new song folder after a rename or conversion. The original source archive is not modified.
- **Funky Maker audio routing:** `Inst.ogg`, `instrumental.ogg`, and `music.ogg` are treated as instrumental candidates and written once as `Inst.ogg`. `Voices*.ogg` tracks remain separate. Other audio is routed to `sounds/` or `audio/extra/`, and `sounds/`, `music/`, and `videos/` folders are copied without being mistaken for the instrumental.
- **Funky Maker health icons:** only the two icon slots referenced by `scene.json` are emitted. Decorative `icon` sprites no longer create extra duplicate health icons.
- **Funky Maker visual transforms:** the runtime applies authored per-animation X/Y scale and keeps replacement-sprite scale, midpoint, alpha, tint, angle, flips, visibility and animation synchronized with the base Psych character. This improves alignment, but is not a claim of pixel-perfect equivalence for every FNMM animation.
- **V-Slice character placement:** AnimateAtlas bounds are reconstructed from the source page/symbol timelines when possible, then used to translate V-Slice bottom-center anchors into Psych top-left character positions. If bounds cannot be reconstructed, the report warns and avoids inventing a size.
- **V-Slice charts and note styles:** the selected NoteStyle is resolved through its fallback chain. Note frames, receptors, and hold-note pieces are merged into the Psych `arrowSkin` atlas and mapped to Psych's expected names. Splash atlases are copied, and a Psych splash JSON config is created only when all four color prefixes can be identified unambiguously. Chart JSON receives `arrowSkin` and `splashSkin` paths.
- **Haxe fallback:** functions translated to Lua remain Lua. When a script/event has unsupported Haxe expressions, the converter preserves the source as `.hx` in the relevant Psych HScript location where possible, records remaining failures in the `_unconverted` report, and avoids writing a duplicate empty Lua handler beside an HScript event.
- **Video calls:** recognized `VideoCutscene.play(Paths.videos(...))` calls are mapped to Psych's `startVideo(...)` entry point. HScript/video capabilities depend on the exact Psych 1.0.4 build configuration.
- **MarvinousTween:** the event is mapped from the supplied Haxe source: `regular` uses a 0.3-second `cubeOut` zoom tween; `custom` reads target zoom, duration, and easing from its comma-separated value. No guessed behavior was added for `disabled` because its handler/parameter data was not included.
- **Asset filtering:** obvious sticker, emote, screenshot, thumbnail, promotional and social assets are excluded from the broad image-copy pass. Required game images are retained; this is a conservative filename/folder filter, not a complete dependency graph.

## Verification and limits

- The supplied FNMM example has two actual `scene.json` icon slots and one `music.ogg`; it has no additional stage SFX, video, note atlas, or splash atlas to validate those paths against.
- The supplied Marvin archive contains diagnostic/Haxe snippets but no audio files. Missing Marvin stage sounds or video files cannot be restored from that archive.
- The uploaded Marvin diagnostics identify `MarvinousTween`; they do not include the implementation or chart values for `disabled`, so that event remains explicitly unresolved rather than receiving invented logic.
- `NoteStyle` splash animation prefixes are not fully described in V-Slice's style JSON. Custom splash config is therefore generated only when the atlas frame names identify all four colors. Otherwise the atlas is preserved and Psych's automatic prefix detection is left in place.
- Validation completed: `NoteStyleAtlas.kt` and `Brain.kt` compiled in isolated Kotlin checks using lightweight API stubs; Python support scripts passed `py_compile`; the packaged and app FNMM Lua runtimes are byte-identical. These are targeted checks, not a full Android compile.
- A full APK build and in-engine gameplay comparison were **not** possible here: this environment has no Gradle executable/wrapper or Android SDK. The resulting archive is the edited Android source project, not an installed APK.
- HScript fallback requires a Psych Engine 1.0.4 build with `HSCRIPT_ALLOWED`; video playback also requires `VIDEOS_ALLOWED`. Not every arbitrary Haxe API is guaranteed to work in the target build, so keep and inspect the converter's `_unconverted` report.

# PortYou Studio - build 1.7 (SpriteMap/audio/Funky Maker revision)

1. **SpriteMap characters:** stop converting native Adobe Animate SpriteMaps into newly rendered Sparrow sheets. The converter retains `Animation.json` and the original page PNG/JSON data. For `multianimateatlas`, it combines symbol/timeline metadata and page references while keeping the art pages intact. V-Slice frame labels are resolved to the symbol IDs that Psych Engine's AnimateAtlas API uses.
2. **No sprite splitting pass:** disable automatic large-sheet cutting and full-mod PNG post-processing. Existing sprite page dimensions are left intact. Funky Maker still packs its source frame strips into one required character atlas, but no longer splits that atlas into additional pages.
3. **Audio:** remove FFmpegKit and the audio mixer. Copy source OGGs without decoding or mixing. V-Slice player/opponent tracks are written as `Voices-Player.ogg` and `Voices-Opponent.ogg`; instrumental tracks are written as `Inst.ogg`. Extra singer tracks remain separate files, and each chart variation gets its own song folder.
4. **Frame-label ranges:** when several V-Slice animation names are labels on one Animate symbol, preserve each label’s frame interval as Psych `indices` (verified against the supplied Pico Kid death atlas: 55, 24, and 66 frames).
5. **Funky Maker fidelity:** preserve stage object X/Y scale, scroll factors, per-animation pivot/offset/scale, alpha, colour, visibility, and fixed-screen placement. Character scale is restored per animation in the runtime. Camera-shake intensity has been reduced to avoid the exaggerated shake in the previous port.
6. **Script library:** embed 162 general Lua scripts from the supplied script pack in the compressed library, alongside the existing event and note-type definitions. Exact-name Haxe conversion fallbacks can use the ready-made script entries.
7. **Project size:** the source tree is kept below 25 MiB. GitHub Actions no longer rejects a release APK for being larger than 25 MiB.

**Verification note:** archive structure, supplied mod examples, audio filenames/metadata, SpriteMap symbol references, and Kotlin/Lua source changes were inspected. A full Android Gradle build and device gameplay test have not been run in this environment.

---

# PortYou Studio - build 1.6 (Brain v2 + library from the real script collection)

The "all scripts" zip (4,193 files: 246 stage scripts, 422 events, 113 note types, 183 global scripts, 587 song scripts, 431 charts) was read this round.

1. **Brain v2** (`Brain.kt`, reference + corpus test in `tools/portyou/brain.py`): works out what an unknown event / note kind does from, in this order, (a) the original source: real API calls and their literal values (keys it listens for, durations, damage), (b) how the charts USE it: value shapes of every event row (colour, bool+character, comma lists, sentences, json) and the side / count of every note, (c) the name: English + Spanish + Portuguese words, also glued names (`slowzoom`, `multsv`). Tested on all 449 kinds used by the 431 charts: every generated Lua is block-balanced.
   New understood behaviours: screen effects (Bloom / Saturation / Vignette ... use the mod's own `.frag` on camGame, on/off from value1), stage zoom (`Change Stage Zoom`, `Camera Zoom Adjust`), bop interval / strength (`Camera Bump Modulo`, `Set Camera Bopping`), `HScript Call` -> `callOnLuas(function, arg)`, video events, cinematic bars, extra characters singing (`opponent4`, `plr3`, `Third Player Note`, `Both Sing`), a character animation named like the kind (`singUP-ugh`) becomes the note's anim suffix, opponent-only kinds are never made damaging.
   Honest fallback: a kind with no evidence gets a safe stub that prints one line, never a wrong guess.
2. **V-Slice converter** now hands the Brain the chart usage (event values, note side / count / sustains) and the mod's shader list.
3. **Library**: +9 events (incl. `SpaceBarNote` - the 5th Space lane with touch button, `Toggle Mechanic`, `GF Play Animation` ...), +1 note type, and a new `scripts` group (bf mechanic, health drain, HealthPullProtect, hold fixes, Stage Change Manager, window change ...) with `Library.script()`.

Not done yet in this build: wiring the `scripts` group into the converters automatically, stage-script reading (246 stages), Brain for Funky Maker custom notes, Kotlin compile (no compiler here - first CI build still pending).

---
# PortYou Studio - build 1.5 (from the real JOJO_N_Pico FNMM mod)

1. **Picker bug**: the V-Slice button refused `.fnmm` (and the extension list differed per button). Both buttons now accept zip / 7z / rar / fnmm and route by the detected mod type.
2. **Funky Maker note props were ignored**: every note carries `props {skin, onPressEvent, onMissEvent}`. Now: skin >= 2 with no action -> Psych `Hurt Note`; any note with an action pack on press/miss -> `custom_notetypes/fnmm-s<skin>-p<pack>-m<pack>.lua` that fires the pack's actions through `triggerEvent` (handled by `fnmm_runtime.lua`). The report lists the counts. (In JOJO: 31 player notes with skin 2.)
3. **Brain** learned more mechanics: jump / fly, move & return, dodge window on SPACE (`keyJustPressed`), extra lives (`onGameOver`), icon change, show / hide object.
4. Stage json of both converters now has `"stageUI": "normal"` (guard against the `cacheCountdown` / `StringMap.set` crash in the supplied log).

Note: the supplied "all scripts" zip only held 6 crash logs, `CREDITS_stuff.lua` and one chart json - no stage / mechanic scripts - so nothing new could be learned from it beyond the crash logs.

---
# PortYou Studio - build 1.4

1. **Big sprites (V-Slice + Funky Maker)**: Animate/spritemap characters are packed into sheets of at most 2048 px; extra frames go to `<name>_2`, `<name>_3` ... linked through the comma separated `image` of the character json. Already-made Sparrow sheets bigger than 2048 px (`ImagePost`, `Atlas.splitSparrow`) are cut the same way, every `SubTexture` attribute kept.
2. **Lossless PNG compression** (`ImageOpt.kt`, optipng-style, same goal as compress2go): indexed PNG + tRNS when <= 256 colours, RGB when nothing is transparent, invisible pixels zeroed, best row filter + Deflate 9. Pixels are never changed, so no blotches and no white/black background. Runs on every image of the finished mod; the size saving is written to PORTYOU_REPORT.txt. (Verified with a Python port against Pillow on 1/2/4/8-bit palette, RGB and RGBA.)
3. **Brain** (`Brain.kt` + `Library.nearest`): an event / note kind with no mapping and no translated Haxe is now (a) matched against the 406 events / 111 note types by words + fuzzy ratio, (b) otherwise built from its name and Haxe source (flash, shake, zoom, fade, alpha, anim, hey, follow, speed, char, angle, text, sound; harmful / healing / alt / no-anim notes). Every generated line is wrapped in pcall.
5. **Note types**: unknown V-Slice note kinds now get `custom_notetypes/<kind>.lua` (library, closest library script, or Brain).
7. Funky Maker: mod detection walks up to 6 folders deep (any folder with data.json + scene.json), `events.json` is optional, BOM-safe json reading, unknown archive magic falls back to zip.

Not done in this build: item 4 (bigger script library - the source scripts were not in this zip), item 6 (the odd arrow positions - needs the screenshot/mod), Python tools mirror (`tools/`) of the new code.

---
# PortYou Studio - build 1.3 (fixes from the Nov 20 test mods)

1. **Funky Maker converter was broken**: new `.FNMM` files (scene.json v4) store positions in `transform[0].position{x,y}` and cameras as `position{x,y}`; the old code read flat `x`/`y` and crashed. Both layouts are read now. Either picker accepts either mod type (routing is by detected type). The real crash text is saved to `cache/last_error.txt`.
2. **Big sprites**: Funky Maker character strips are cut into several atlases (max 2048 px each, weak-phone/GPU safe) and linked through a comma separated `image` (`characters/x,characters/x_2`).
3. **Black screen in V-Slice ports**: stage props with a numeric `scale` (1.75) were not scaled at all; a prop image that is missing (even in the original mod) now becomes a colour block instead of an empty black stage.
4. **"Error on lua script!"** (`'then' expected near '?'`, `'<name>' expected near "v1"`): Haxe `?.`, ternaries, `{ name: v }` literals, object-method calls and capitalised engine classes are now refused (function reported, never written). Every converted callback runs inside `pcall`, `getEventSchema/getTitle` are dropped, `super.*()` calls are removed.
5. **Library**: `library.json.gz` (406 events, 111 note types, from the supplied collection) + new Haxe->Lua rules (Std.*, FlxG.sound, camFollow, Paths.*). FlashWhite and Drunk now work through runtime events.
6. **Mod name** = the original archive/folder name (meta title only as the last fallback).
7. **Akram**: 11 new sayings in all 6 languages (last one shows the fail icon on the bubble), text moved down/right, "يا زول" -> "يا زم".

---
# PortYou Studio — what changed in this build

1. **Charts (V-Slice + Funky Maker)**: Psych 1.0 `psych_v1` charts use ABSOLUTE lanes (0-3 player, 4-7 opponent); `mustHitSection` only moves the camera. The old converter flipped lanes inside every "opponent" section, which swapped player/opponent arrows. Fixed. GF arrows are written with the `GF Sing` note type (FNMM strumLine 2+, V-Slice note kind `gf`).
2. **Funky Maker "Null Object Reference" in `PlayState.generateSong`**: the chart had no `events` key. Events are now stored inside the chart (no separate events.json).
3. **Black screen / wrong screen**: runtime scripts rewritten defensively (colour parsing never falls back to black, zoom/alpha clamped, every event wrapped in pcall, camera starts on a defined point, FNMM objects are layered relative to the real character index, FNMM zoom uses the same 0.7 factor as the stage).
4. **Haxe -> Lua** (`tools/portyou/hx2lua.py`): per-function, many files at once, rule table in `methods.json` ("haxe"), optional local AI (`PORTYOU_LLM_URL`). Anything not convertible is moved OUT of the mod into `<mod>_unconverted/` with `ماقدرت_احول_ذا_COULD_NOT_CONVERT.txt` (ar/en/pt/ja) — only created when something failed.
5. **Spritemaps**: smart label matching (exact / prefix / normalised / fuzzy / optional AI) between the mod's character json animation names and the Animate atlas labels.
6. **Credits**: every converted mod gets `scripts/portyou_credit.lua` (the supplied text.lua with "Port You Studio") besides pack.json/pack.png.

7. **Kotlin V-Slice port** (this build): `Atlas.kt` (Animate spritemap reader + Sparrow packer on Android Canvas/Matrix, no Pillow), `Hx2Lua.kt` (same per-function rules as `hx2lua.py`, reads `assets/converter/methods.json`), `VSliceConverter.kt` (charts, events, characters, stages, weeks, credits, report), so V-Slice mods convert fully on the phone without Termux/Python.
8. **Vocal merging on the phone**: `AudioMerge.kt` uses `dev.ffmpegkit-maintained:ffmpeg-kit-audio:6.0.3` (libvorbis, `amix=normalize=0`). Needs minSdk 24 and arm64 only (that is all the maintained fork publishes). If ffmpeg fails the first vocal file is used and a warning is written to the report.
9. `<mod>_unconverted/` (Haxe the converter could not translate) is now also copied to the save folder.
10. **ASTC textures -> PNG** (`Astc.kt`): pure-Kotlin ASTC LDR decoder (all 2D block sizes 4x4..12x12, dual-plane, 1-4 partitions, void-extent, CEM 0/1/4/5/6/8/9/10/12/13) for raw `.astc` and KTX1 files. Detected by file header (not extension), run right after extraction, streamed to PNG row by row (low RAM). Failures go to `PORTYOU_REPORT.txt` and the original file is kept. HDR endpoints = magenta; KTX2 / 3D not supported.
